﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Core.Utilities.AzureStorage
{
    public class BlobService
    {
        public string DefaultEndPoint { get; set; }
        public string ContainerName { get; set; }
        public string Url { get; set; }
    }
}
