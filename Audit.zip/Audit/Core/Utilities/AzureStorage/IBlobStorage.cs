﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace Core.Utilities.AzureStorage
{
    public interface IBlobStorage
    {
        Task<string> UploadAsnyc(Stream fileStream, string name, string contentType);
        Task<Stream> DownloadAsync(string fileName, string containerName);
        Task DeleteAsync(string fileName);
        Task SetLogAsync(string text, string fileName);
        Task<List<string>> GetLogAsync(string fileName);
        List<string> GetNames(string containerNames);
    }
}
