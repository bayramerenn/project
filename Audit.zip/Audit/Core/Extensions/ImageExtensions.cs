﻿using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;

namespace Core.Extensions
{
    public static class ImageExtensions
    {
        public static string GetMimeType(this Image image)
        {
            return image.RawFormat.GetMimeType();
        }

        public static string GetMimeType(this ImageFormat imageFormat)
        {
            ImageCodecInfo[] codecInfo = ImageCodecInfo.GetImageEncoders();
            return codecInfo.First(codec => codec.FormatID == imageFormat.Guid).MimeType;
        }

        public static Stream ToStream(this Image image, ImageFormat imageFormat)
        {
            MemoryStream stream = new MemoryStream();

            image.Save(stream, imageFormat);
            stream.Position = 0;
            return stream;
        }

        public static string GetFilenameExtension(this ImageFormat format)
        {
            return ImageCodecInfo.GetImageEncoders().FirstOrDefault(x => x.FormatID == format.Guid).FilenameExtension;
        }
    }
}