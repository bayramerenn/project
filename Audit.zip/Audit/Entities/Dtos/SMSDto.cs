﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.Dtos
{
    public class SMSDto
    {
        public int SmsId { get; set; }
        public string Signature{ get; set; }
    }
}
