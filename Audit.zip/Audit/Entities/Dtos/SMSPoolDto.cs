﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.Dtos
{
    public class SMSPoolDto
    {
        public string ApproverCode { get; set; }
        public string ApproverName { get; set; }
        public string Phone { get; set; }
        public int AnswerHeaderId { get; set; }
    }
}
