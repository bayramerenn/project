﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.Dtos
{
    public class AnswerLineDto
    {
        public int AnswerHeaderId { get; set; }
        public int QuestionId { get; set; }
        public int AnswerTypeId { get; set; }
        public string Comment { get; set; }
        public string ExemptComment { get; set; }
        public string[] ImageUrl { get; set; }
    }
}
