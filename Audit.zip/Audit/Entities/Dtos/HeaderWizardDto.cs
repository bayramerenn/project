﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.Dtos
{
    public class HeaderWizardDto
    {
        public int AnswerHeaderId { get; set; }
        public int SmsId { get; set; }
        public string Comment { get; set; }
        public float Latitude { get; set; }
        public float Longitude { get; set; }
    }
}
