﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.Models
{
    public class AnswerHeader
    {
        public int AnswerHeaderId { get; set; }
        public int StoreId { get; set; }
        public int QuestionGroupId { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public string Comment { get; set; }
        public string ImagePath { get; set; }
        public bool IsFinished { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public string CreatedUserName { get; set; }
        public string UpdatedUserName { get; set; }

    }
}


	

