﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.Models
{
    public class NebimPersonel
    {
        public string ApproverCode { get; set; }
        public string ApproverName { get; set; }
        public string Phone { get; set; }
    }
}
