﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Entities.Models
{
    public class SMSPool
    {
        [Key]
        public int SmsId { get; set; }
        public int AnswerHeaderId { get; set; }
        public string Message { get; set; }
        public string SendUserName { get; set; }
        public int MessageResponseId { get; set; }
        public string ApproverCode { get; set; }
        public string ApproverName { get; set; }
        public int Signature { get; set; }
        public string Phone { get; set; }
    }
}
