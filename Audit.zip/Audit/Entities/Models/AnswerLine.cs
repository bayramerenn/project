﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.Models
{
    public class AnswerLine
    {
        public int AnswerLineId { get; set; }
        public int AnswerHeaderId { get; set; }
        public int QuestionId { get; set; }
        public int AnswerTypeId { get; set; }
        public string Comment { get; set; }
        public string ExemptComment { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public string ImagePath { get; set; }
        public string CreatedUserName { get; set; }
        public string UpdatedUserName { get; set; }
    }
}
