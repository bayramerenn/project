﻿namespace Entities.Models
{
    public class QuestionGroup
    {
        public int QuestionGroupId { get; set; }
        public string QuestionGroupName { get; set; }
    }
}