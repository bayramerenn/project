﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Entities.Models
{
    public class AssignedQuestions
    {
        [Key]
        public int QuestionId { get; set; }
        public string QuestionName { get; set; }
        public string SectionName { get; set; }
    }
}
