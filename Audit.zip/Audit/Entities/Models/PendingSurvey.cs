﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.Models
{
    public class PendingSurvey
    {
        public int AnswerHeaderId { get; set; }
        public DateTime StartTime { get; set; }
        public string StoreDescription { get; set; }
        public string QuestionGroupName { get; set; }
    }
}
