﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Entities.Models
{
    public class Question
    {
        [Key]
        public int QuestionId { get; set; }
        public string QuestionName { get; set; }
              public double QuestionScore { get; set; }
        public int QuestionSectionId { get; set; }
        public bool IsActive { get; set; }
        public string CreatedUserName { get; set; }
        public string UpdatedUserName { get; set; }
    }
}
