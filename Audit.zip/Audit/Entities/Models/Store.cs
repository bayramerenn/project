﻿namespace Entities.Models
{
    public class Store
    {
        public int StoreId { get; set; }
        public string StoreCode { get; set; }
        public string StoreDescription { get; set; }
    }
}