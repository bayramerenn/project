﻿using Business.Constants;
using Core.Utilities.Results;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;
using WebApi.Authentication.Models;
using WebApi.Authentication.Securty.Jwt;
using WebApi.Models;
using Mapster;
namespace WebApi.Controllers
{
    [AllowAnonymous]
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly UserManager<AppUser> _userManager;
        private readonly RoleManager<AppRole> _roleManager;
        private readonly ITokenHelper _tokenHelper;

        public AuthController(UserManager<AppUser> userManager, RoleManager<AppRole> roleManager, ITokenHelper tokenHelper)
        {
            _userManager = userManager;
            _roleManager = roleManager;
            _tokenHelper = tokenHelper;
        }

        [HttpPost]
        [Route("login")]
        public async Task<IActionResult> Login([FromBody] LoginModel model)
        {
            var user = await _userManager.FindByEmailAsync(model.Email);

            if (user != null && await _userManager.CheckPasswordAsync(user, model.Password))
            {
                var userRoles = await _userManager.GetRolesAsync(user);



                var accessToken = _tokenHelper.CreateToken<AccessToken>(user, userRoles.ToList());




                return Ok(new
                {
                    UserId = user.Id,
                    FullName = user.FirstName+' '+user.LastName,
                    Role = userRoles.ToList(),
                    AccessToken= accessToken,
                    Email = user.Email
                });
            }
            return Unauthorized();
        }

        [HttpPost]
        [Route("register")]
        public async Task<IActionResult> Register([FromBody] RegisterModel model)
        {
            var userExists = await _userManager.FindByEmailAsync(model.Email);
            if (userExists != null)
                return StatusCode(StatusCodes.Status500InternalServerError, new Result(false, Messages.UsingMailAdress));

            AppUser user = new AppUser()
            {
                Email = model.Email,
                UserName = model.Email,
                FirstName = model.FirstName,
                LastName = model.LastName
            };
            var result = await _userManager.CreateAsync(user, model.Password);
            if (!result.Succeeded)
            {
                string value = "";
                foreach (var item in result.Errors)
                {
                    value += item.Description;
                }
                return StatusCode(StatusCodes.Status500InternalServerError, new Result(false, value));
            }

        

            return Ok(new Result(true, Messages.CreatedUser));
        }

        [HttpPost]
        [Route("createrole")]
        public async Task<IActionResult> CreateRole([FromBody] RoleModel roleModel)
        {
           
            var name = roleModel.RoleName.Substring(0, 1).ToUpper() + roleModel.RoleName.Substring(1).ToLower();
            var role =await _roleManager.FindByNameAsync(name);
            if (role != null)
            {
                return BadRequest(new Result(false,Messages.RoleExisting));
            }

            AppRole appRole = new AppRole();
            appRole.Name = name;
            var result = await _roleManager.CreateAsync(appRole);
            if (!result.Succeeded)
            {
                return BadRequest(new Result(false, Messages.RoleError));
            }
            return Ok(new Result(true, name+ Messages.RoleCreated));
        }

        [HttpGet]
        [Route("roles")]
        public IActionResult GetRoles()
        {

            var roles =  _roleManager.Roles.ToList();

            var roleModel = roles.Adapt<AppRole>();
            
            return Ok(roleModel);
        }

        [HttpGet]
        [Route("assingrole")]
        public IActionResult AssingRole()
        {


            //_userManager.Role
            //var roles = _roleManager.Roles.ToList();

            //var roleModel = roles.Adapt<AppRole>();

            return Ok();
        }

    }
}