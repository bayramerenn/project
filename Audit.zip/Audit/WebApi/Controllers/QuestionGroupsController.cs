﻿using Business.Abstract;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class QuestionGroupsController : ControllerBase
    {

        private readonly IQuestionGroupService _questionService;

        public QuestionGroupsController(IQuestionGroupService questionGroupService)
        {
            _questionService = questionGroupService;
        }
        [HttpGet]
        public async Task<IActionResult> GetQuestionGroups(int storeId)
        {
            var result = await _questionService.GetQuestionGroupsAsync(storeId);
            return Ok(result);
        }
    }
}
