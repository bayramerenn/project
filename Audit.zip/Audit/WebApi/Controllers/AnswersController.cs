﻿using Business.Abstract;
using Business.Constants;
using Core.Extensions;
using Core.Utilities.AzureStorage;
using Core.Utilities.Results;
using Entities.Dtos;
using Entities.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AnswersController : ControllerBase
    {
        //private UploadConfig _config;

        //public AnswersController(UploadConfig config)
        //{
        //    _config = config;
        //}

        private readonly IAnswerHeaderService _answerHeaderService;
        private readonly IAnswerLineService _answerLineService;
        private readonly IBlobStorage _blobStorage;
        private readonly ISMSPoolService _smsPoolService;

        public AnswersController(IAnswerHeaderService answerHeaderService, IBlobStorage blobStorage, IAnswerLineService answerLineService, ISMSPoolService smsPoolService)
        {
            _answerHeaderService = answerHeaderService;
            _blobStorage = blobStorage;
            _answerLineService = answerLineService;
            _smsPoolService = smsPoolService;
        }

        [HttpPost("CreateAnswerLine")]
        public async Task<IActionResult> CreateAnswerLine(List<AnswerLineDto> answerLineDto)//IFormFile[] imageUrl,
        {
            var answerHeader = await _answerHeaderService.GetAnswerHeaderAsync(answerLineDto[0].AnswerHeaderId);

            List<AnswerLine> answerLines = new List<AnswerLine>();

            foreach (var item in answerLineDto)
            {
                AnswerLine answerLine = new AnswerLine();
                answerLine.AnswerHeaderId = item.AnswerHeaderId;
                answerLine.AnswerTypeId = item.AnswerTypeId;
                answerLine.QuestionId = item.QuestionId;
                answerLine.Comment = item.Comment;
                answerLine.ExemptComment = item.ExemptComment;
                answerLine.CreatedDate = DateTime.Now;
                answerLine.UpdatedDate = DateTime.Now;
                answerLine.CreatedUserName = User.Identity.Name;
                answerLine.UpdatedUserName = User.Identity.Name;

                answerLine.ImagePath = item.ImageUrl.Length == 0 ?
                                             "" :
                                            await GetPathUrl(item);
                answerLines.Add(answerLine);
            }

            answerHeader.EndTime = DateTime.Now;
            answerHeader.IsFinished = true;
            await _answerHeaderService.UpdateAnswerHeaderAsync(answerHeader);

            var result = await _answerLineService.CreateAnswerRangeLineAsync(answerLines);
            return Ok(result);
        }

        [HttpPost("CreateAnswerHeader")]
        public async Task<IActionResult> CreateAnswerHeader(AnswerHeader answerHeader)
        {
            answerHeader.CreatedDate = DateTime.Now;
            answerHeader.UpdatedDate = DateTime.Now;
            answerHeader.StartTime = DateTime.Now;
            answerHeader.EndTime = DateTime.Now;
            answerHeader.CreatedUserName = User.Identity.Name;
            answerHeader.UpdatedUserName = User.Identity.Name;

            var result = await _answerHeaderService.CreateAnswerHeaderAsync(answerHeader);
            if (result.Success)
            {
                return Ok(result.Data);
            }
            return BadRequest(result.Message);
        }

        [HttpPost("AnswerHeaderPhotosCreate")]
        public async Task<IActionResult> CreateAnswerHeaderPhoto(IFormFile formFile)
        {
            var answerHeaderId = formFile.FileName.Split('-')[0];
            var path = $"{answerHeaderId}/{formFile.FileName}";

            var stream = formFile.OpenReadStream();
            var result = await _blobStorage.UploadAsnyc(stream, path,formFile.ContentType);

            if (result != null)
            {
                
                var data =await _answerHeaderService.UpdateAnswerHeaderPhotoAsync(int.Parse(answerHeaderId), result);

                if (data.Success)
                {
                    return Ok(data);
                }
                return BadRequest(data);
            }

            return BadRequest(Messages.AnswerHeaderAzuraPhotoError);
        }

    

       

        [HttpPost("PendingSurveys")]
        public async Task<IActionResult> GetPendingSurveys(int[] headerIds)
        {
            var result = await _answerHeaderService.GetPendingSurveysAsync(headerIds);
            return Ok(result);
        }

        [HttpPost("Sms")]
        public  async Task<IActionResult> SMS(SMSPoolDto smsPoolDto)
        {
            var response = SendSmsMessage(smsPoolDto.Phone,smsPoolDto.ApproverName);
           
            if (response.MessageId.Length == 2)
            {
                SMSPool smsPool = new SMSPool();

                smsPool.AnswerHeaderId = smsPoolDto.AnswerHeaderId;
                smsPool.ApproverCode = smsPoolDto.ApproverCode;
                smsPool.ApproverName = smsPoolDto.ApproverName;
                smsPool.Message = response.Message;
                smsPool.MessageResponseId = Convert.ToInt32(response.MessageId[1]);
                smsPool.Phone = smsPoolDto.Phone;
                smsPool.SendUserName = User.Identity.Name;
                smsPool.Signature = response.signature;

                var result = await _smsPoolService.CreateSmsAsync(smsPool);
                if (result.Success)
                {
                    return Ok(result);
                }
                return BadRequest(result);
            }
            return BadRequest("Sms gönderilemedi.Lütfen yöneticinizle irtibata geçiniz.");
        }

        [HttpPut("UpdateAnswerLine")]
        public async Task<IActionResult> UpdateAnswerLine(List<AnswerLineDto> answerLineDto)//IFormFile[] imageUrl,
        {
            var answerHeader = await _answerHeaderService.GetAnswerHeaderAsync(answerLineDto[0].AnswerHeaderId);

            List<AnswerLine> answerLines = new List<AnswerLine>();

            foreach (var item in answerLineDto)
            {
                AnswerLine answerLine = new AnswerLine();
                answerLine.AnswerHeaderId = item.AnswerHeaderId;
                answerLine.AnswerTypeId = item.AnswerTypeId;
                answerLine.QuestionId = item.QuestionId;
                answerLine.Comment = item.Comment;
                answerLine.ExemptComment = item.ExemptComment;
                answerLine.CreatedDate = DateTime.Now;
                answerLine.UpdatedDate = DateTime.Now;
                answerLine.CreatedUserName = User.Identity.Name;
                answerLine.UpdatedUserName = User.Identity.Name;

                answerLine.ImagePath = item.ImageUrl.Length == 0 ?
                                             "" :
                                            await GetPathUrl(item);
                answerLines.Add(answerLine);
            }

            answerHeader.EndTime = DateTime.Now;
            answerHeader.IsFinished = true;
            await _answerHeaderService.UpdateAnswerHeaderAsync(answerHeader);

            var result = await _answerLineService.UpdateAnswerLineRangeAsync(answerLines);
            return Ok(result);
        }

        [HttpPut("HeaderWizardUpdate")]

        public async Task<IActionResult> HeaderWizardUpdate(HeaderWizardDto headerWizardDto)
        {
            var result = await _answerHeaderService.UpdateHeaderWizardDtoAsync(headerWizardDto);
            if (result.Success)
            {
                return Ok(result);
            }

            return BadRequest(result);
        }


        [HttpDelete("AnswerHeaderPhotosDelete")]
        public async Task<IActionResult> DeleteAnswerHeaderPhoto(string fileName)
        {
            try
            {
                var answerHeaderId = fileName.Split('-')[0];
                var imageName = $"{answerHeaderId}/{fileName}";
                await _blobStorage.DeleteAsync(imageName);
                var result = await _answerHeaderService.DeleteAnswerHeaderPhotoAsync(int.Parse(answerHeaderId), imageName);
                if (result.Success)
                {
                    return Ok(result);
                }
                return BadRequest(result);
            }
            catch (Exception)
            {
                return BadRequest(Messages.AnswerHeaderAzuraPhotoDeleteError);

            }


        }
        [HttpDelete("ImagePathReset")]
        public async Task<IActionResult> ImagePathReset(int answerHeaderId)
        {
            var result = await _answerHeaderService.RemoveImagePathReset(answerHeaderId);
            if (result.Success)
            {
                return Ok(result);
            }

            return BadRequest(result);
        }
        [HttpDelete]
        public async Task<IActionResult> DeleteAnswerHeader(int answerHeaderId)
        {
            var result = await _answerHeaderService.DeleteAnswerHeaderAsync(answerHeaderId);
            if (result.Success)
            {
                return Ok(result);
            }

            return BadRequest(result);
        }

        private async Task<string> GetPathUrl(AnswerLineDto answerLineDto)
        {
            string result = "";
            try
            {
                for (int i = 0; i < answerLineDto.ImageUrl.Length; i++)
                {
                    var image = await Base64ToImageAsync(answerLineDto.ImageUrl[i]);
                    var contentType = image.GetMimeType();
                    var fileExtension = image.RawFormat.FileExtensionFromEncoder();
                    var stream = image.ToStream(image.RawFormat);
                    var path = $"{answerLineDto.AnswerHeaderId}/{answerLineDto.QuestionId}/{answerLineDto.QuestionId}-{i}{fileExtension}";
                    result += await _blobStorage.UploadAsnyc(
                         stream,
                         path,
                        contentType);
                    if (i < answerLineDto.ImageUrl.Length - 1)
                    {
                        result += "&";
                    }
                }

                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return result;
            }

            // Convert byte[] to Image
        }
        private (string[] MessageId,string Message,int signature) SendSmsMessage(string phone, string fullName)
        {
            var random = new Random();
            var signature = random.Next(100000,999999);
            string message = $"Sayın {fullName}, İmza numaranız {signature}";
            var someXmlString = $@"
                  <MainmsgBody>
                    <Command>0</Command>
                    <PlatformID>1</PlatformID>
                    <ChannelCode>636</ChannelCode>
                    
                    <Mesgbody>{message}</Mesgbody>
                    <Numbers>90{phone}</Numbers>
                    <Type>2</Type>
                    <Concat>1</Concat>
                    <Option>1</Option>
                    <Originator>Civil</Originator>
                </MainmsgBody>
                ";

            var httpWebRequest = (HttpWebRequest)WebRequest.Create("http://processor.smsorigin.com/xml/process.aspx");
            httpWebRequest.ContentType = "text/xml";
            httpWebRequest.Method = "POST";

            XmlDocument soapEnvelopeXml = new XmlDocument();
            soapEnvelopeXml.LoadXml(someXmlString);



            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                soapEnvelopeXml.Save(streamWriter);

            }

            var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
            string result;
            using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            {
                result = streamReader.ReadToEnd();

            }
            var split = result.Split(":");
            return (split, message, signature);
        }
        private async Task<Image> Base64ToImageAsync(string imageBase64)
        {
            var value = imageBase64.Substring(imageBase64.LastIndexOf(',') + 1);
            byte[] imageBytes = Convert.FromBase64String(value);

            MemoryStream ms = new MemoryStream(imageBytes, 0, imageBytes.Length);
            await ms.WriteAsync(imageBytes, 0, imageBytes.Length);
            return Image.FromStream(ms, true);
        }
    }
}

