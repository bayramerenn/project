﻿using Business.Abstract;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class PersonelsController : ControllerBase
    {
        private readonly IPersonelService _personelService;

        public PersonelsController(IPersonelService personelService)
        {
            _personelService = personelService;
        }

        [HttpGet("GetPersonels")]
        public async Task<IActionResult> GetPersonels(string storeCode)
        {
            var result = await _personelService.GetNebimPersonel(storeCode);
            return Ok(result.Data);
        }
    }
}
