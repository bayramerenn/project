﻿using Business.Abstract;
using Business.Concrete;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class QuestionsController : ControllerBase
    {
        private readonly IQuestionService _questionService;

        public QuestionsController(IQuestionService questionService)
        {
            _questionService = questionService;
        }

        [HttpGet]
        public async Task<IActionResult> GetQuestions(int questionGroupId)
        {
            var result = await _questionService.GetQuestionsAsync(questionGroupId);

            return Ok(result);
        }

        [HttpGet("GetQuestionAll")]
        public async Task<IActionResult> GetQuestionAll()
        {
            var result = await _questionService.GetQuestionAll();

            return Ok(result);
        }
    }
}
