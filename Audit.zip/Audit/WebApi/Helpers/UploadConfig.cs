﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Helpers
{
    public class UploadConfig
    {
        public string DirectoryBasePath { get; set; }
        public string UrlBasePath { get; set; }
    }
}