﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WebApi.Authentication.Securty.Jwt
{
    public interface IAccessToken
    {
        DateTime Expiration { get; set; }
        string Token { get; set; }
    }
}
