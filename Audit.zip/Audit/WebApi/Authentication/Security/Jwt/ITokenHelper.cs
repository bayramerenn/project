﻿using System;
using System.Collections.Generic;
using System.Text;
using WebApi.Authentication.Models;

namespace WebApi.Authentication.Securty.Jwt
{
    public interface ITokenHelper
    {
        TAccessToken CreateToken<TAccessToken>(AppUser user, List<string> appRoles)
            where TAccessToken : IAccessToken, new();
    }
}
