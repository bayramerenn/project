﻿using Core.Extensions;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using WebApi.Authentication.Models;
using WebApi.Authentication.Security.Encyption;
using WebApi.Authentication.Securty.Jwt;

namespace WebApi.Authentication.Security.Jwt
{
    public class JwtHelper : ITokenHelper
    {
        public IConfiguration Configuration { get; }
        public readonly TokenOption _tokenOptions;
        private DateTime _accessTokenExpiration;

        public JwtHelper(IConfiguration configuration)
        {
            Configuration = configuration;
            _tokenOptions = Configuration.GetSection("TokenOptions").Get<TokenOption>();
        }

        public TAccessToken CreateToken<TAccessToken>(AppUser user, List<string> roles) where TAccessToken : IAccessToken, new()
        {
            var getDate = DateTime.Now.ToString("yyyy/MM/dd 23:59:52");
            _accessTokenExpiration = DateTime.Parse(getDate);
            var security = SecurityKeyHelper.CreateSecurityKey(_tokenOptions.SecurityKey);
            var signingCredentials = SigninCredentialsHelper.CreateSigningCredentials(security);
            var jwt = CreateSecurityToken(_tokenOptions, user, signingCredentials, roles);
            var jwtSecurityTokenHandler = new JwtSecurityTokenHandler();
            var token = jwtSecurityTokenHandler.WriteToken(jwt);

            return new TAccessToken
            {
                Token = token,
                Expiration = _accessTokenExpiration
            };
        }

        public JwtSecurityToken CreateSecurityToken(TokenOption tokenOptions, AppUser user, SigningCredentials signingCredentials, List<string> operationClaims)
        {
            var jwt = new JwtSecurityToken(
                    issuer: tokenOptions.Issuer,
                    audience: tokenOptions.Audience,
                    expires: _accessTokenExpiration,
                     notBefore: DateTime.Now,
                    claims: SetClaims(user, operationClaims),
                    signingCredentials: signingCredentials

                );

            return jwt;
        }
        private IEnumerable<Claim> SetClaims(AppUser user, List<string> roles)
        {
            var claims = new List<Claim>();
            claims.AddEmail(user.Email);
            claims.AddName(user.FirstName+" "+user.LastName);
            claims.AddNameIdentifier(user.Id.ToString());
            claims.AddRoles(roles.ToArray());

            return claims;
        }
    }
}
