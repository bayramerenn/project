export const environment = {
  production: true,
  appVersion: 'v723demo3',
  USERDATA_KEY: 'authf649fc9a5f55',
  isMockEnabled: true,
  apiUrl: 'https://localhost:5001/api'
  // apiUrl: 'mysite.com/api'
};
