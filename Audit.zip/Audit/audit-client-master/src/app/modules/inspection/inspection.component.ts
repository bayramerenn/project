import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild,
} from "@angular/core";

import { Observable } from "rxjs/internal/Observable";
import {
  map,
  filter,
  debounceTime,
  distinctUntilChanged,
} from "rxjs/operators";
import { Store } from "src/app/entities/store";
import { StoreService } from "src/app/services/store.service";
import { ToastrService } from "ngx-toastr";
import { Router } from "@angular/router";
import { merge, Subject, OperatorFunction, BehaviorSubject } from "rxjs";
import { NgbTypeahead } from "@ng-bootstrap/ng-bootstrap/typeahead/typeahead";
import { QuestionService } from "src/app/services/question.service";
import { QuestionGroup } from "src/app/entities/question-group";
import { AnswerHeader } from "src/app/entities/answer-header";
import { AnswerHeaderService } from "src/app/services/answer-header.service";
import { Question } from "src/app/entities/question";

import { NgxSpinnerService } from "ngx-spinner";
import { AnswerLocalStorage } from "src/app/entities/answer-local-storage";
import { PendingSurvey } from "src/app/entities/pending-survey";
@Component({
  selector: "app-inspection",
  templateUrl: "./inspection.component.html",
  styleUrls: ["./inspection.component.scss"],
})
export class InspectionComponent implements OnInit {
  model: Store;

  @ViewChild("instance", { static: true }) instance: NgbTypeahead;
  focusStore$ = new Subject<string>();
  clickStore$ = new Subject<string>();
  store: Store[];
  questionGroup: QuestionGroup[];
  selectGroupId: number;
  pendingSurveys:PendingSurvey[]
  answerHeader: AnswerHeader = new AnswerHeader();
  getQuestionDataSubject$: BehaviorSubject<Question[]> = new BehaviorSubject(
    []
  );

  constructor(
    private storeService: StoreService,
    private questionGroupService: QuestionService,
    private toastr: ToastrService,
    private router: Router,
    private answerHeaderService: AnswerHeaderService,
    private spinner: NgxSpinnerService,
   
  ) {}

  ngOnInit(): void {
    this.storeService.getStores().subscribe((store) => {
      this.store = store;
      
    });

    let answerLocalStorage = (JSON.parse(localStorage.getItem('answer')) as AnswerLocalStorage[])
    

    if (answerLocalStorage) {
        if (answerLocalStorage.length > 0) {
      let headerIds = answerLocalStorage.map(data => {
        return data.answerHeaderId
      })
     
      this.answerHeaderService.getPendingSurveys(headerIds)
          .subscribe(pendingData => {
            this.pendingSurveys = pendingData
            
          })
    }
  
    }
  
  }

  searchStore: OperatorFunction<
    string,
    readonly { storeId;storeCode; storeDescription }[]
  > = (text$: Observable<string>) => {
    const debouncedText$ = text$.pipe(
      debounceTime(200),
      distinctUntilChanged()
    );
    const clicksWithClosedPopup$ = this.clickStore$.pipe(
      filter(() => !this.instance.isPopupOpen())
    );
    const inputFocus$ = this.focusStore$;

    return merge(debouncedText$, inputFocus$, clicksWithClosedPopup$).pipe(
      map((term) =>
        (term === ""
          ? this.store
          : this.store.filter(
              (v) =>
                v.storeDescription.toLowerCase().indexOf(term.toLowerCase()) >
                -1
            )
        ).slice(0, 10)
      )
    );
  };

  formatter = (x: { storeDescription: string }) => x.storeDescription;

  onSubmit() {
    if (this.selectGroupId) {
      this.spinner.show();
      this.answerHeader.storeId = this.model.storeId;
      this.answerHeader.questionGroupId = this.selectGroupId;

      this.answerHeaderService
        .createAnswerHeader(this.answerHeader)
        .subscribe((data) => {
          localStorage.setItem(
            "questionGroupId",
            this.selectGroupId.toString()
          );
          setTimeout(() => {
            /** spinner ends after 5 seconds */
            this.spinner.hide();
            this.router.navigateByUrl("inspection/survey/" + data.answerHeaderId);
          }, 3000);
        
        });
    } else {
      this.toastr.error("Lütfen mağaza ve anket seçiniz");
    }
    
  }

  selectQuestionGroup(event) {
    this.selectGroupId = Number(event);
  }
  selectStore(event) {

    localStorage.setItem('storeCode',event.item.storeCode)
    this.questionGroupService
      .getQuestionGroupsByStoreId(event.item.storeId)
      .subscribe((data) => {
        this.questionGroup = data;
      });
  }

  deleteStorage(headerId:number){


    this.answerHeaderService.deleteAnswer(headerId).subscribe(
      (data) => {
        this.toastr.success(data.message);
        
        let answerLocalStorage = (JSON.parse(localStorage.getItem('answer')) as AnswerLocalStorage[])
    
        let response =  answerLocalStorage.filter(f => f.answerHeaderId !== headerId);
    
        localStorage.setItem('answer',JSON.stringify(response));
    
        let index = this.pendingSurveys.findIndex(i => i.answerHeaderId === headerId);
        this.pendingSurveys.splice(index,1)


      },
      (error) => {
        this.toastr.error(error.error.message);
      }
    );


   


  }
}
