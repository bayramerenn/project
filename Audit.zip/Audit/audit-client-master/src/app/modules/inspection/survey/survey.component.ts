import {
  Component,
  ElementRef,
  Input,
  OnDestroy,
  OnInit,
  ViewChild,
} from "@angular/core";
import { ToastrService } from "ngx-toastr";

// import Swal from "sweetalert2/dist/sweetalert2.js";
import { AnswerLine, AnswerType } from "src/app/entities/answer-lines";
import { Question } from "src/app/entities/question";

import { AnswerLineService } from "src/app/services/answer-line.service";
import { QuestionService } from "src/app/services/question.service";
import { AnswerHeaderService } from "src/app/services/answer-header.service";
import { ActivatedRoute, Router } from "@angular/router";
import { NgxSpinnerService } from "ngx-spinner";
import { AnswerLocalStorage } from "src/app/entities/answer-local-storage";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { AnswerParentTransfer, CrudType } from "src/app/entities/viewmodels/answer-parent-transfer";

@Component({
  selector: "app-survey",
  templateUrl: "./survey.component.html",
  styleUrls: ["./survey.component.scss"],
})
export class SurveyComponent implements OnInit, OnDestroy {
  @ViewChild("content") myContent: ElementRef;

  public yes = false;
  public no = false;
  public exempt = false;
  files: File[] = [];
  answerLines: AnswerLine[] = [];
  base64textString = [];
  question: Question[];
  questionGroupId: number;
  answerHeaderId: number;
  answerLocalStorage: AnswerLocalStorage;
  updateAnswerLines: AnswerLine[];
  answerHeaderFile: File[] = [];
  answerParentTransfer : AnswerParentTransfer;

  constructor(
    private toastr: ToastrService,
    private answerLineService: AnswerLineService,
    private questionService: QuestionService,
    private answerHeaderService: AnswerHeaderService,
    private route: ActivatedRoute,
    private router: Router,
    private spinner: NgxSpinnerService,
    private modalService: NgbModal
  ) {
    this.answerParentTransfer = new AnswerParentTransfer(CrudType.create);
  }

  // ngAfterViewInit() {
  //    this.openLarge(this.myContent);
  // }
  ngOnDestroy(): void {
    localStorage.removeItem("answer-old");
    localStorage.removeItem("storeCode");
    localStorage.removeItem("questionGroupId");
  }

  ngOnInit(): void {
    this.answerHeaderId = +this.route.snapshot.paramMap.get("id");

    let questionGroupId = Number(localStorage.getItem("questionGroupId"));
    this.questionService.getQuestion(questionGroupId).subscribe((question) => {
      this.question = question;

      this.checkAnswerLocalStorage();

      this.createAnswerLocalStorage(question);

      if (question.length == 0) {
        this.toastr.error("Anket seçmeden işlem yapamazsınız");
        this.goInspection();
      }
    });
  }

  deleteFile() {
    this.answerHeaderService.deleteAnswer(this.answerHeaderId).subscribe(
      (data) => {
        this.toastr.success(data.message);
        this.goInspection();
        localStorage.removeItem("questionGroupId");
      },
      (error) => {
        this.toastr.error(error.error.message);
      }
    );
  }
  goInspection() {
    this.router.navigateByUrl("/inspection");
  }
  onYes(
    yes,
    no,
    exempt,
    questionId,
    commentAnswerCollapse,
    exemptAnswerCollapse
  ) {
    no.checked = false;
    exempt.checked = false;
    commentAnswerCollapse.value = "";
    exemptAnswerCollapse.value = "";

    let answerLine: AnswerLine;
    if (yes.checked) {
      let qId = this.checkQuestion(questionId);

      if (qId < 0) {
        let question = this.getQuestionById(questionId);
        answerLine = new AnswerLine(
          this.answerHeaderId,
          questionId,
          AnswerType.yes,
          question.questionName,
          question.sectionName
        );
        this.answerLines.push(answerLine);
      } else {
        this.answerLines[qId].answerTypeId = AnswerType.yes;
        this.answerLines[qId].imageUrl = [];
        this.answerLines[qId].comment = "";
        this.answerLines[qId].file = [];

        answerLine = this.answerLines[qId];
      }
    }

    this.updateAnswerLocalStorage(answerLine);
  }

  onNo(yes, no, exempt, questionId, exemptAnswerCollapse) {
    yes.checked = false;
    exempt.checked = false;

    exemptAnswerCollapse.value = "";
    let answerLine: AnswerLine;
    if (no.checked) {
      let qId = this.checkQuestion(questionId);
      if (qId < 0) {
        let question = this.getQuestionById(questionId);
        answerLine = new AnswerLine(
          this.answerHeaderId,
          questionId,
          AnswerType.no,
          question.questionName,
          question.sectionName
        );
        this.answerLines.push(answerLine);
      } else {
        this.answerLines[qId].answerTypeId = AnswerType.no;
        answerLine = this.answerLines[qId];
      }
    }

    this.updateAnswerLocalStorage(answerLine);
  }
  onExempt(yes, no, exempt, questionId, commentAnswerCollapse) {
    yes.checked = false;
    no.checked = false;
    commentAnswerCollapse.value = "";
    let answerLine: AnswerLine;

    if (exempt.checked) {
      let qId = this.checkQuestion(questionId);
      if (qId < 0) {
        let question = this.getQuestionById(questionId);
        answerLine = new AnswerLine(
          this.answerHeaderId,
          questionId,
          AnswerType.exempt,
          question.questionName,
          question.sectionName
        );
        this.answerLines.push(answerLine);
      } else {
        this.answerLines[qId].answerTypeId = AnswerType.exempt;
        this.answerLines[qId].imageUrl = [];
        this.answerLines[qId].comment = "";

        this.answerLines[qId].file = [];

        answerLine = this.answerLines[qId];
      }
    }

    this.updateAnswerLocalStorage(answerLine);
  }

  onKey(comment, questionId, key) {
    let qId = this.checkQuestion(questionId);
    if (qId > -1) {
      if (key === "no") {
        this.answerLines[qId].comment = comment;
      } else {
        this.answerLines[qId].exemptComment = comment;
      }
    }
    this.updateAnswerLocalStorage(this.answerLines[qId]);
  }

  onSelect(event, questionId) {
    let array = Array.from<File>(event.addedFiles);

    let qId = this.checkQuestion(questionId);

    if (qId > -1) {
      array.forEach((data) => {
        this.getBase64(data).then((test) => {
          if (this.answerLines[qId].imageUrl.length < 3) {
            this.files.push(...event.addedFiles);

            this.answerLines[qId].imageUrl.push(test as string);
            this.answerLines[qId].file.push(data);

            this.updateAnswerLocalStorage(this.answerLines[qId]);
          } else {
            this.toastr.error("En fazla 3 resim ekleyebilirsiniz");
          }
        });
      });
    }
  }
  onModalSelect(event) {
    this.answerHeaderFile.push(...event.addedFiles);
  }
  onRemove(event, questionId) {
    let index = this.answerLines
      .find((f) => f.questionId === questionId)
      .file.indexOf(event);
    let qId = this.checkQuestion(questionId);

    this.answerLines[qId].file.splice(index, 1);
    this.answerLines[qId].imageUrl.splice(index, 1);

    this.updateAnswerLocalStorage(this.answerLines[qId]);
  }
  onModalRemove(event) {
    this.answerHeaderFile.splice(this.files.indexOf(event), 1);
  }
  getBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);

      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (error) => reject(error);
    });
  }

  getQuestionById(questionId: number): Question {
    return this.question.find((f) => f.questionId === questionId);
  }

  getFiles(questionId: number) {
    let value = this.answerLines.find((f) => f.questionId === questionId).file;

    return value;
  }
  checkedFiles(questionId: number) {
    let qId = this.checkQuestion(questionId);
    if (qId > -1) {
      return true;
    } else {
      return false;
    }
  }
  checkQuestion(questionId: number): number {
    return this.answerLines.findIndex((f) => f.questionId === questionId);
  }
  checkAnswerLocalStorage() {
    localStorage.removeItem("answer-old");
    let data = JSON.parse(
      localStorage.getItem("answer")
    ) as AnswerLocalStorage[];
    if (data && data.find((f) => f.answerHeaderId !== this.answerHeaderId)) {
      localStorage.setItem("answer-old", JSON.stringify(data));
    }
  }
  getAnswerOldLocalStorage(): AnswerLocalStorage[] {
    let data = JSON.parse(
      localStorage.getItem("answer-old")
    ) as AnswerLocalStorage[];

    if (data !== null) {
      return data.filter((f) => f.answerHeaderId !== this.answerHeaderId);
    }

    return null;
  }

  updateAnswerLocalStorage(answerLine: AnswerLine) {
    let addLocalStorage: AnswerLocalStorage[] = [];

    let index = this.answerLocalStorage.answerLines.findIndex(
      (i) => i.questionId === answerLine.questionId
    );

    this.answerLocalStorage.answerLines[index] = answerLine;

    let answerOldLocalStorage = this.getAnswerOldLocalStorage();

    if (answerOldLocalStorage !== null) {
      answerOldLocalStorage.length > 1
        ? addLocalStorage.push(...answerOldLocalStorage)
        : addLocalStorage.push(answerOldLocalStorage[0]);

      addLocalStorage.push(this.answerLocalStorage);
      this.setLocalStorage(addLocalStorage);
    } else {
      addLocalStorage.push(this.answerLocalStorage);
      this.setLocalStorage(addLocalStorage);
    }
  }
  createAnswerLocalStorage(question: Question[]) {
    let addLocalStorage: AnswerLocalStorage[] = [];
    let answerLines = question.map((m) => {
      return new AnswerLine(
        this.answerHeaderId,
        m.questionId,
        AnswerType.noSelected,
        m.questionName,
        m.sectionName
      );
    });

    this.answerLocalStorage = new AnswerLocalStorage(
      this.answerHeaderId,
      answerLines
    );

    let answerOldLocalStorage = this.getAnswerOldLocalStorage();
    if (answerOldLocalStorage !== null && answerOldLocalStorage.length !== 0) {
      answerOldLocalStorage.length > 1
        ? addLocalStorage.push(...answerOldLocalStorage)
        : addLocalStorage.push(answerOldLocalStorage[0]);

      addLocalStorage.push(this.answerLocalStorage);
      this.setLocalStorage(addLocalStorage);
    } else {
      addLocalStorage.push(this.answerLocalStorage);
      this.setLocalStorage(addLocalStorage);
    }
  }

  setLocalStorage(answerLocalStorage: any) {
    localStorage.setItem("answer", JSON.stringify(answerLocalStorage));
  }

  openLarge(content) {
    this.answerParentTransfer.answerLine = this.answerLines.map((answer) => {
      return {
        answerHeaderId: answer.answerHeaderId,
        answerTypeId: answer.answerTypeId,
        comment: answer.comment,
        exemptComment: answer.exemptComment,
        imageUrl: answer.imageUrl,
        questionId: answer.questionId,
      };
    });

    this.modalService.open(content, {
      size: "lg",
    });
    // if(this.answerLines.length === this.question.length || this.answerLines.length  >= 0){

    // }else{
    //     this.toastr.error('Eksik kayıtlar mevcut lütfen tüm soruları cevaplayınız')
    // }
  }
}
