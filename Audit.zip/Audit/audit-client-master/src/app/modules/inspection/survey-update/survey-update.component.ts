import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { filter } from 'rxjs/operators';
import { AnswerLine, AnswerType } from 'src/app/entities/answer-lines';
import { AnswerLocalStorage } from 'src/app/entities/answer-local-storage';
import { Question } from 'src/app/entities/question';
import { AnswerParentTransfer, CrudType } from 'src/app/entities/viewmodels/answer-parent-transfer';
import { AnswerHeaderService } from 'src/app/services/answer-header.service';
import { AnswerLineService } from 'src/app/services/answer-line.service';

@Component({
  selector: 'app-survey-update',
  templateUrl: './survey-update.component.html',
  styleUrls: ['./survey-update.component.scss']
})
export class SurveyUpdateComponent implements OnInit {

  answerLocalStorage:AnswerLocalStorage;
  answerLines: AnswerLine[] = [];
  answerHeaderId: number;
  files: File[] = [];
  answerParentTransfer : AnswerParentTransfer;

  constructor(
    private route:ActivatedRoute,
    private cdref: ChangeDetectorRef,
    private toastr: ToastrService,
    private answerHeaderService: AnswerHeaderService,
    private answerLineService: AnswerLineService,
    private router: Router,
    private modalService: NgbModal
    ) {

      this.answerParentTransfer = new AnswerParentTransfer(CrudType.create);
     }

  ngAfterContentChecked() {

  
    this.cdref.detectChanges();

  }
  ngOnInit(): void {
    this.answerHeaderId = Number(this.route.snapshot.paramMap.get('id'))

    let answer = JSON.parse(localStorage.getItem('answer')) as AnswerLocalStorage[]

   this.answerLocalStorage = answer.find(f => f.answerHeaderId === this.answerHeaderId);

    this.answerLines = this.answerLocalStorage.answerLines;

    let sayi =0;

   
   
    this.answerLocalStorage.answerLines.forEach(answer => {
      if (answer.imageUrl.length !== 0) {
        for (let index = 0; index < answer.imageUrl.length; index++) {
       
          let file = this.dataURLtoFile(answer.imageUrl[index],`${answer.questionId}-${index}`)
          answer.file[index] = file;
         }
      }
    })

   
  }

  onYes(yes, no, exempt, questionId, commentAnswerCollapse,exemptAnswerCollapse){
    no.checked = false;
    exempt.checked = false;
    commentAnswerCollapse.value = "";
    exemptAnswerCollapse.value = "";
    if (yes.checked) {
      let qId = this.checkQuestion(questionId);

      this.answerLines[qId].answerTypeId = AnswerType.yes;
      this.answerLines[qId].imageUrl = [];
      this.answerLines[qId].comment = "";
      this.answerLines[qId].file = [];
    }
 

    this.updateAnswerLocalStorage(this.answerLines);
  }
  onNo(yes, no, exempt, questionId,exemptAnswerCollapse) {
    yes.checked = false;
    exempt.checked = false;

    exemptAnswerCollapse.value = "";
    if (no.checked) {
      let qId = this.checkQuestion(questionId);
      this.answerLines[qId].answerTypeId = AnswerType.no;
    }
   
    this.updateAnswerLocalStorage(this.answerLines);
  }
  onExempt(yes, no, exempt, questionId, commentAnswerCollapse) {
    yes.checked = false;
    no.checked = false;
    commentAnswerCollapse.value = "";
   
    if (exempt.checked) {
      let qId = this.checkQuestion(questionId);

      this.answerLines[qId].answerTypeId = AnswerType.exempt;
      this.answerLines[qId].imageUrl = [];
      this.answerLines[qId].comment = "";

      this.answerLines[qId].file = [];
    }
  
    this.updateAnswerLocalStorage(this.answerLines);
  }

  onKey(comment, questionId,key) {
    let qId = this.checkQuestion(questionId);
    if (qId > -1) {

      if (key === 'no') {
        this.answerLines[qId].comment = comment;
      }else{
        this.answerLines[qId].exemptComment = comment;
      }
      this.answerLines[qId].comment = comment;
      this.updateAnswerLocalStorage(this.answerLines);
    }
    
  }

  openLarge(content) {
   
    if(this.answerLines.length === this.answerLocalStorage.answerLines.length ){
      this.answerParentTransfer.answerLine = this.answerLines.map((answer) => {
        return {
          answerHeaderId: answer.answerHeaderId,
          answerTypeId:answer.answerTypeId,
          comment: answer.comment,
          exemptComment: answer.exemptComment,
          imageUrl: answer.imageUrl,
          questionId: answer.questionId,
        };
      });
  
  
      this.modalService.open(content, {
        size: "lg",
      });
    }else{
        this.toastr.error('Eksik kayıtlar mevcut lütfen tüm soruları cevaplayınız')
        
    }
  }

  onSelect(event, questionId) {
    let array = Array.from<File>(event.addedFiles);

    let qId = this.checkQuestion(questionId);

    if (qId > -1) {
      array.forEach((data) => {
        this.getBase64(data).then((test) => {
          if (this.answerLines[qId].imageUrl.length < 3) {
            this.files.push(...event.addedFiles);

            this.answerLines[qId].imageUrl.push(test as string);
            this.answerLines[qId].file.push(data);

            this.updateAnswerLocalStorage(this.answerLines);
          } else {
            this.toastr.error("En fazla 3 resim ekleyebilirsiniz");
          }
        });
      });
    }
  }
  onRemove(event, questionId) {
    let index = this.answerLines
      .find((f) => f.questionId === questionId)
      .file.indexOf(event);
    let qId = this.checkQuestion(questionId);

    this.answerLines[qId].file.splice(index, 1);
    this.answerLines[qId].imageUrl.splice(index, 1);

    this.updateAnswerLocalStorage(this.answerLines)
  }

 
  getBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);

      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (error) => reject(error);
    });
  }
  getQuestionById(questionId:number):Question{
    return this.answerLocalStorage.answerLines.find(f => f.questionId ===questionId);
  }
  

  
  checkQuestion(questionId: number): number {
    return this.answerLines.findIndex((f) => f.questionId === questionId);
  }

  updateAnswerLocalStorage(answerLine: AnswerLine[]){
    let answerLocalStorage = this.deleteAnswerLSByHeaderId()

    answerLocalStorage.push(new AnswerLocalStorage(this.answerHeaderId,answerLine))

    this.setLocalStorage(answerLocalStorage);


  }

  setLocalStorage(answerLocalStorage:any){
    localStorage.setItem("answer", JSON.stringify(answerLocalStorage));
  }

  dataURLtoFile(dataurl, filename) {
    const type = dataurl.split(";")[0].split("/")[1];

    var arr = dataurl.split(","),
      mime = arr[0].match(/:(.*?);/)[1],
      bstr = atob(arr[1]),
      n = bstr.length,
      u8arr = new Uint8Array(n);

    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }

    return new File([u8arr], `${filename}.${type}`, { type: mime });
  }

  deleteAnswerLSByHeaderId():AnswerLocalStorage[]{
    let answerLocalStorage = JSON.parse(localStorage.getItem('answer')) as AnswerLocalStorage[]

    let index = answerLocalStorage.findIndex(index => index.answerHeaderId === this.answerHeaderId);

    answerLocalStorage.splice(index,1)

    return answerLocalStorage;
  }
  deleteFile() {
    this.answerHeaderService.deleteAnswer(this.answerHeaderId).subscribe(
      (data) => {
        this.toastr.success(data.message);
        let answerLocalStorage = this.deleteAnswerLSByHeaderId()
        this.setLocalStorage(answerLocalStorage);
       
        this.goInspection();
        
      },
      (error) => {
        this.toastr.error(error.error.message);
      }
    );
  }
  onSubmit() {
    var data = this.answerLines
    .filter(f => f.answerTypeId > -1)
    .map((answer) => {
     
        return {
          answerHeaderId: answer.answerHeaderId,
          answerTypeId: answer.answerTypeId,
          comment: answer.comment,
          imageUrl: answer.imageUrl,
          questionId: answer.questionId,
        };
      
    
    });

    this.answerLineService.createAnswerLine(data).subscribe((response) => {
      let answerLocalStorage = this.deleteAnswerLSByHeaderId()
      this.setLocalStorage(answerLocalStorage);
      this.goInspection();
      this.toastr.success(response.message);
    });
  }
  goInspection() {
    this.router.navigateByUrl("/inspection");
  }
}
