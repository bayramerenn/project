import {
  AfterViewInit,
  Component,
  ElementRef,
  Input,
  OnDestroy,
  OnInit,
  ViewChild,
} from "@angular/core";
import KTWizard from "../../../../assets/js/components/wizard";
import { KTUtil } from "../../../../assets/js/components/util";

import { HttpClient } from "@angular/common/http";
import { Observable, of } from "rxjs";
import { PersonelService } from "src/app/services/personel.service";

import { NebimPersonel } from "src/app/entities/nebim-personel";
import { SmsPoolDto } from "src/app/entities/sms-pool-dto";
import { ActivatedRoute } from "@angular/router";
import { SmsSendService } from "src/app/services/sms-send.service";
import { Result } from "src/app/entities/result";
import { ToastrService } from "ngx-toastr";
import { AnswerHeaderService } from "src/app/services/answer-header.service";
import { v4 as uuidv4 } from 'uuid';
import { SMSDto } from "src/app/entities/smsDto";
import { HeaderWizard } from "src/app/entities/header-wizard";
import { AnswerLineService } from "src/app/services/answer-line.service";
import { AnswerParentTransfer, CrudType } from "src/app/entities/viewmodels/answer-parent-transfer";


@Component({
  selector: "app-header-wizard",
  templateUrl: "./header-wizard.component.html",
  styleUrls: ["./header-wizard.component.scss"],
})
export class HeaderWizardComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild("wizard", { static: true }) el: ElementRef;
  @Input('answerLine') answerLine:AnswerParentTransfer;
  headerDescription: string;
  headerWizardClass:HeaderWizard;
  answerHeaderFile: File[] = [];
  isSendSms: boolean = false;
  apiLoaded: Observable<boolean>;
  smsPoolDto = new SmsPoolDto();
  center: google.maps.LatLngLiteral = { lat: 38.7729, lng: 35.357729 };
  answerHeaderId: number;
  zoom = 5;
  isLocation: boolean = false;
  isSigneture: boolean = false;
  phone: string = "5497926770";
 
  result:Result<SMSDto> = new Result();

  wizard: any;
  storeCode: string;
  nebimPersonel: NebimPersonel[] = [];

  constructor(
    httpClient: HttpClient,
    private personelService: PersonelService,
    private router: ActivatedRoute,
    private smsSendService: SmsSendService,
    private toastr:ToastrService,
    private answerHeaderService:AnswerHeaderService,
    private answerLineService:AnswerLineService
  ) {
    // this.apiLoaded = httpClient.jsonp('https://maps.googleapis.com/maps/api/js?key=AIzaSyApr2gnq-xl_1mi6jmtRogmin2y_50n4XE', 'callback')
    // .pipe(
    //   map(() => true),
    //   catchError(() => of(false)),
    // );
    this.headerWizardClass = new HeaderWizard();
  }

  ngOnInit(): void {
    this.answerHeaderId = Number(this.router.snapshot.paramMap.get("id"));
    this.storeCode = localStorage.getItem("storeCode");
    this.personelService.getNebimPersonel(this.storeCode).subscribe((data) => {
      this.nebimPersonel = data;
    });

    this.smsPoolDto.answerHeaderId = this.answerHeaderId;
    this.smsPoolDto.approverCode = "230";
    this.smsPoolDto.approverName = "Bayram EREN";
    this.smsPoolDto.phone = this.phone;
  }

  ngAfterViewInit() {
    // Initialize form wizard
    this.wizard = new KTWizard(this.el.nativeElement, {
      startStep: 1,
    });

    
    // Validation before going to next page
    this.wizard.on("beforeNext", (wizardObj) => {
      // https://angular.io/guide/forms
      // https://angular.io/guide/form-validation
      // validate the form and use below function to stop the wizard's step
      // wizardObj.stop();
      
    });

    this.wizard.on('change', (wizardObj) => {
      
      wizardObj.stopped = false;
      });

    
    
    // Change event
    this.wizard.on("change", () => {
      setTimeout(() => {
        KTUtil.scrollTop();
      }, 500);
    });
  }

  onSubmit() {
    
    this.headerWizardClass.answerHeaderId = this.answerHeaderId;
    this.headerWizardClass.comment = this.headerDescription;
    this.headerWizardClass.smsId = this.result.data.smsId;

    console.log(this.answerLine)

    if (this.answerLine.crudType === CrudType.create) {
      this.answerLineService.createAnswerLine(this.answerLine.answerLine).subscribe((data) => {

        console.log(data)
  
        // localStorage.removeItem("answer");
      });
    } 
    if(this.answerLine.crudType === CrudType.update) {
      this.answerLineService.updateAnswerLine(this.answerLine.answerLine).subscribe((data) => {

        console.log(data)
  
        // localStorage.removeItem("answer");
      });
    }

   
    this.answerHeaderService.UpdateAnswerWizard(this.headerWizardClass).subscribe(
      response => {
          console.log(response)
      },err => console.log(err)
    )
    
  }
  onSms() {
    this.isSendSms = true;
    this.smsSendService.sendSms(this.smsPoolDto).subscribe(
      (result) => {
      
        if (result.success) {
          this.result = result;
          this.toastr.success(result.message);

        }
        
      },
      (err) => console.log(err),
      () => (this.isSendSms = false)
    );
  }
  ngOnDestroy() {
    this.wizard = undefined;
   
    if (!(this.isLocation && this.isSigneture)) {
      this.answerHeaderService.RemoveImagePathReset(this.answerHeaderId);
    }
  }

  onPersonel(event) {
    this.phone = event.target.value;

    this.smsPoolDto.approverCode =
      event.target.options[event.target.selectedIndex].dataset.sectionvalue;
    this.smsPoolDto.approverName =
      event.target.options[event.target.selectedIndex].text;
    this.smsPoolDto.phone = event.target.value;
    this.smsPoolDto.answerHeaderId = this.answerHeaderId;

    
  }
  onSignature(data:string){
    if (data == this.result.data.signature) {
      this.isSigneture = true;
      this.toastr.success('Şifre doğru girdiniz.')
    } else{
      this.isSigneture = false;
      this.toastr.error('Şifre hatalı girdiniz.')
    }
  }
  onModalRemove(event) {
   
    this.answerHeaderService.DeleteAnswerHeaderPhoto(event.name).subscribe(response => {
     
      this.answerHeaderFile.splice(this.answerHeaderFile.indexOf(event), 1);
    })
    // this.answerHeaderFile.splice(this.answerHeaderFile.indexOf(event), 1);
  }

  onModalSelect(event) {
 
    let fileNameSplit = event.addedFiles[0].name.split('.');

    let fileName =`${this.answerHeaderId}-${uuidv4()}.${fileNameSplit[fileNameSplit.length - 1]}`

    const formData = new FormData();

      
    formData.append('formFile',event.addedFiles[0],fileName)
    // event.addedFiles[0].name = fileName;
   

    

    this.answerHeaderService.CreateAnswerHeaderPhoto(formData).subscribe()

    this.answerHeaderFile.push(formData.get('formFile') as File);

  
  }

  getLocation() {
    this.getLocationService().then((resp) => {
      this.center = { lat: resp.lat, lng: resp.lng };
      this.zoom = 15;
      this.isLocation = true;

      this.headerWizardClass.latitude = resp.lat;
      this.headerWizardClass.longitude = resp.lng;
    });
  }

  getLocationService(): Promise<any> {
    return new Promise((resolve, reject) => {
      navigator.geolocation.getCurrentPosition((resp) => {
        resolve({
          lng: resp.coords.longitude,
          lat: resp.coords.latitude,
        });
      });
    });
  }
}
