import { NgModule,CUSTOM_ELEMENTS_SCHEMA,NO_ERRORS_SCHEMA } from "@angular/core";
import { CommonModule } from "@angular/common";
import { NgxSpinnerModule } from "ngx-spinner";
import { RouterModule, Routes } from "@angular/router";

import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { GoogleMapsModule } from '@angular/google-maps';
import { HttpClientJsonpModule, HttpClientModule } from "@angular/common/http";
import { NgxDropzoneModule } from 'ngx-dropzone';
import {  NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { SweetAlert2Module } from "@sweetalert2/ngx-sweetalert2";

// Components
import { SurveyUpdateComponent } from './survey-update/survey-update.component';
import { HeaderWizardComponent } from './header-wizard/header-wizard.component';
import { InspectionComponent } from "./inspection.component";
import { SurveyComponent } from "./survey/survey.component";
import { NgxMaskModule, IConfig } from 'ngx-mask'
export const options: Partial<IConfig> | (() => Partial<IConfig>) = null;


const routes: Routes = [
  {
    path: "",
    component: InspectionComponent,
  },
  {
    path: "survey/:id",
    component: SurveyComponent,
  },
  {
    path: "survey-update/:id",
    component: SurveyUpdateComponent,
  },
];

@NgModule({
  declarations: [InspectionComponent, SurveyComponent, SurveyUpdateComponent, HeaderWizardComponent],
  imports: [
    CommonModule,
    NgxDropzoneModule,
    NgxSpinnerModule,
    HttpClientModule,
    GoogleMapsModule,
    NgbModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientJsonpModule,
    SweetAlert2Module.forRoot({
      provideSwal: () => import('sweetalert2').then(({ default: swal }) => swal.mixin({
        // example: set global options here
        confirmButtonText: `Evet`,
        cancelButtonText: `Vazgeç`
      }))
    }),
    NgxMaskModule.forRoot(),
    RouterModule.forChild(routes),
  ],
  providers: [],
  schemas:[CUSTOM_ELEMENTS_SCHEMA,NO_ERRORS_SCHEMA]
})
export class InspectionModule {}
