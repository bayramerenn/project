import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wizards',
  templateUrl: './wizards.component.html',
})
export class WizardsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
