import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-saved-credit-cards',
  templateUrl: './saved-credit-cards.component.html',
  styleUrls: ['./saved-credit-cards.component.scss']
})
export class SavedCreditCardsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
