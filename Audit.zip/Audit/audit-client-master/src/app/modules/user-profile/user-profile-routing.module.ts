import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AccountInformationComponent } from './account-information/account-information.component';


import { ProfileOverviewComponent } from './profile-overview/profile-overview.component';
import { SavedCreditCardsComponent } from './saved-credit-cards/saved-credit-cards.component';
import { StatementsComponent } from './statements/statements.component';
import { TaxInformationComponent } from './tax-information/tax-information.component';
import { UserProfileComponent } from './user-profile.component';

const routes: Routes = [
  {
    path: '',
    component: UserProfileComponent,
    children: [
      {
        path: 'profile-overview',
        component: ProfileOverviewComponent,
      },
   
      {
        path: 'account-information',
        component: AccountInformationComponent
      },
  
      {
        path: 'saved-credic-cards',
        component: SavedCreditCardsComponent
      },
      {
        path: 'tax-information',
        component: TaxInformationComponent
      },
      {
        path: 'statements',
        component: StatementsComponent
      },
      { path: '', redirectTo: 'profile-overview', pathMatch: 'full' },
      { path: '**', redirectTo: 'profile-overview', pathMatch: 'full' },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class UserProfileRoutingModule { }
