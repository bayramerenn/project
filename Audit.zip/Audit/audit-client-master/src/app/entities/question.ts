export class Question{
    questionId:number;
    questionName:string;
    sectionName:string;
}