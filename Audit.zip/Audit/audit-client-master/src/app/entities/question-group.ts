export class QuestionGroup{
    questionGroupId:number;
    questionGroupName:string;
}