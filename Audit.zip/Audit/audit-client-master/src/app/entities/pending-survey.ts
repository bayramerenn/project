export class PendingSurvey{
    answerHeaderId:number;
    startTime:Date;
    storeDescription:string;
    questionGroupName:string;
}