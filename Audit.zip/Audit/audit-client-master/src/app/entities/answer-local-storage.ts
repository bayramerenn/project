import { AnswerLine } from "./answer-lines";

export class AnswerLocalStorage {
    answerHeaderId: number;
    answerLines: AnswerLine[];
  
    constructor(answerHeaderId: number, answerLines: AnswerLine[]) {
      this.answerHeaderId = answerHeaderId;
      this.answerLines = answerLines;
    }
  }