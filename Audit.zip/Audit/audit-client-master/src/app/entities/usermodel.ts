export class UserModel{
    fullName:string;
    email:string;
    userId:string;
    role:string[]
    accessToken:Token;
}

class Token{
    token:string;
    expiration:Date
}