export class NebimPersonel{
    approverCode:string;
    approverName:string;
    phone:string;
}