export class Result<T>{
    message:string;
    success:boolean;
    data:T;
}