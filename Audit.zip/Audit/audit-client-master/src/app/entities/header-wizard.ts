export class HeaderWizard{
    answerHeaderId:number;
    comment:string;
    latitude:number;
    longitude:number;
    smsId:number;
}