export class Store {
    storeId:number;
    storeCode:string;
    storeDescription:string;

}
