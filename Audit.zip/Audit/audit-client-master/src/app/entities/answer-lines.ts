export class AnswerLine{
    answerHeaderId:number;
    questionId:number;
    answerTypeId:AnswerType;
    comment:string='';
    exemptComment:string='';
    imageUrl?:string[] = [];
    file?:File[] =[]
    questionName:string;
    sectionName:string;
    
    constructor( answerHeaderId:number,
        questionId:number,
        answerTypeId:AnswerType,
        questionName:string,
        sectionName:string
                ) {
        this.answerHeaderId = answerHeaderId;
        this.answerTypeId = answerTypeId;
        this.questionId = questionId;
        this.questionName = questionName;
        this.sectionName = sectionName;
              
    }
}

export enum AnswerType{
    noSelected = -1,
    no = 0,
    yes = 1,
    exempt = 2

}