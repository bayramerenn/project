export class SMSDto{
    smsId:number;
    signature:string;
}