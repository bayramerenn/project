export class SmsPoolDto{
    approverCode:string;
    approverName:string;
    phone:string;
    answerHeaderId:number;
}