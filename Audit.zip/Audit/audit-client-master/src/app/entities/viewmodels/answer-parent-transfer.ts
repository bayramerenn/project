export class AnswerParentTransfer{
    crudType:CrudType;
    answerLine:any
    constructor(crudType:CrudType) {
        this.crudType = crudType
    }
}

export enum CrudType{
    create,
    update
}