export class AnswerHeader{
    answerHeaderId:number;
    storeId:number;
    questionGroupId:number;
    latitude:number;
    longitude:number;
    startTime:Date;
    EndTime:Date;
    Comment:string;
    imagePath:string;
    isFinished:boolean;
    createdDate:Date;
    updatedDate:Date;
    createdUserName:string;
    updatedUserName:string;


}