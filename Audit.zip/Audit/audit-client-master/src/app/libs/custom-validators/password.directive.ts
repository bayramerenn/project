import { Directive } from '@angular/core';
import { AbstractControl, NG_VALIDATORS, ValidationErrors, Validator, ValidatorFn } from '@angular/forms';
import { EmailDirective } from './email.directive';


export const passwordValidator:ValidatorFn = (
  control:AbstractControl
):ValidationErrors | null => {

  var PASSWORD_REGEXP = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/gm;

  if (  control.value != '' && !PASSWORD_REGEXP.test(control.value)) {
    return {isPassword:true}
  }

  return null;
}
@Directive({
  selector: '[appPassword]',
  providers:[
    {provide:NG_VALIDATORS,useExisting:EmailDirective,multi:true}
  ]
})
export class PasswordDirective implements Validator {

  constructor() { }
  validate(control: AbstractControl): ValidationErrors {
    return passwordValidator(control)
  }
  

}
