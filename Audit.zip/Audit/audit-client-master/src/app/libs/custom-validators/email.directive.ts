import { Directive } from '@angular/core';
import {
  AbstractControl,
  FormGroup,
  NG_VALIDATORS,
  ValidationErrors,
  Validator,
  ValidatorFn
} from '@angular/forms';

export const emailValidator: ValidatorFn = (
  control: AbstractControl
): ValidationErrors | null => {
 

  var EMAIL_REGEXP = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/g;

  if (
    control.value != '' &&
    (control.value.length <= 5 || !EMAIL_REGEXP.test(control.value))
  ) {
    return { isEmail: true };
  }

  return null;
};

@Directive({
  selector: '[appEmail]',
  providers: [
    { provide: NG_VALIDATORS, useExisting: EmailDirective, multi: true }
  ]
})
export class EmailDirective implements Validator {
  constructor() {}
  validate(control: AbstractControl): ValidationErrors {
    return emailValidator(control);
  }
}
