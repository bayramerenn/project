export const QuestionFake = [
    {
       "QuestionId":1,
       "QuestionName":"2 Aylık Deneme Süresi Değerlendirme Formu dolduruluyor mu? (İşe yeni başlamış personel için 55. gün değerlendirilmesi yapılması gerekmektedir)",
       "SectionName":"iş kanunu ve çalışma"
    },
    {
       "QuestionId":2,
       "QuestionName":"A4 fiyat çerçevelerinde kurumsal çalışmalar uygulanmış mı ? ( Calıbri yazı stili,civil şablonlu kağıt olarak kullanılmalıdır)",
       "SectionName":"görsel "
    },
    {
       "QuestionId":3,
       "QuestionName":"Acil durum eylem planı var mı ? (Eylem planı depo girişinde asılı olmalı, acil durumda görevli isimler belirlenmiş ve isimler güncel olmalı.Deposu dışarıda ise ayrıca asılmalı.)",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":4,
       "QuestionName":"Acil duruma neden olan olaya ilişkin (yangın, gaz kaçağı, ilk yardım ,deprem vb.) telefon numaraları asılımı ? (Depo girişi ,duyuru panosu ve kasa arkasına asılmalı)",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":5,
       "QuestionName":"Araç gereç servis kayıt defteri ve formu aktif kullanıyor mu ? ( Servis formu açılarak kontrol edilir.)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":6,
       "QuestionName":"Araç-gereç ürünlerinde alarm takılı mı?(10 ürüne bakılıp (%10) en az 1 ve üzeri üründe alarm takılı değilse olumsuz not verilir.)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":7,
       "QuestionName":"Asansör acil durum alarm butonu çalışıyor mu?(Müşteri ve yük asansörü deneme yapılarak kontrol edilir)",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":8,
       "QuestionName":"Asansör aydınlatma sistemi çalışıyor mu ? (Müşteri ve yük asansörlerin tüm ışıkları yanıyor olmalı.)",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":9,
       "QuestionName":"Asansör havalandırma sistemi çalışıyor mu ? (Müşteri ve yük asansörünü denenerek kontrol edilir)",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":10,
       "QuestionName":"Asansör kabin içi telefon çalışıyor mu ? (Müşteri ve yük asansörünü deneyerek kontrol edilir.Telefon acil durumda yetkili kişilerin duyup anlık iletişime geçebilecekleri konumda olmalı)",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":11,
       "QuestionName":"Asansör kapısının sensörü çalışıyor mu?(Müşteri ve yük asansörünü deneyerek kontrol edilir. )",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":12,
       "QuestionName":"Asansör makine dairesi kapısı kapalı ve kilitli mi ? (Kilitli olmalı yetkisiz kişiler girmemeli .)",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":13,
       "QuestionName":"Asansör makine dairesinin çevresinde tehlike oluşturacak ürün veya çeşitli malzemelerden arındırılmış mı ? (Etrafı tamamen boş olmalı.)",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":14,
       "QuestionName":"Asansör muayenesi yapılmış mı,uygunluk etiketi var mı?Yoksa eksiklikler için gerekli bildirimler yapılmış mı?(Yeşil veya mavi etiket olmalı,kırmızı olmamalı)",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":15,
       "QuestionName":"Asansörün aylık periyodık bakımları yaptırılmış mı?(Bakım formları kayıt altına alınmış mı,kontrol edilir)",
       "SectionName":"muhasebe ve ofis "
    },
    {
       "QuestionId":16,
       "QuestionName":"Bebe ürünlerinde alarm takılı mı? (100 ürüne bakılıp (%10) en az 10 ve üzeri üründe alarm takılı değilse olumsuz not verilir.)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":17,
       "QuestionName":"Bebe ürünlerinde askılama doğru yapılmış mı?(Civil askısı olmalı, yaş gruplarına göre doğru askı takılmalı ve tek tip olmalı.100 ürüne bakılıp (%10) en az 10 ve üzeri üründe askılama doğru değilse ise olumsuz not verilir.)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":18,
       "QuestionName":"Bebe ürünlerinde etiketleme doğru yapılmış mı ?  ( İç barkot ile dış barkot kontrolü yapılarak uyumları kontrol edilir.100 ürüne bakılıp (%10) en az 10 ve üzeri üründe iç barkot ile dış barkot uyumlu değilse olumsuz not verilir.)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":19,
       "QuestionName":"Bebe ürünlerinde fiyat değişiklikleri uygulanmış mı ? (El terminali ile kontrol edilir 100 ürüne bakılır (%10) en az 10 ve üzeri ürünlerde fiyat değişikliği yapılmadıysa olumsuz not verilir.Aynı gün gelen fiyat değişikliği dahil değildir.)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":20,
       "QuestionName":"Bebek bakım odası temizliği yapılmış mı bakım ünitesinde alt açma var mı çöp kovası poşetli ve temiz mi?(Bakım odasında askılık olmalı,müşterilerin çanta ve montlarını asabilmeleri için)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":21,
       "QuestionName":"Bölge müdürü veya mağaza müdürü tarafından görevlendirilen personele görevlendirme formu doldurulmuş mu ? (Özlük dosyalarından kontrol edilir.Son 30 güne bakılır.)",
       "SectionName":"iş kanunu ve çalışma"
    },
    {
       "QuestionId":22,
       "QuestionName":"Çelik kasa anahtarları sorumlularda mı ? (Anahtarlar, en az şef, müdür ve md.yrd.olmalıdır.)",
       "SectionName":"muhasebe ve ofis "
    },
    {
       "QuestionId":23,
       "QuestionName":"Çelik kasa üzerinde anahtar olmamalı ve kasalar kilitli olmalıdır. (2 konuda önemlidir. Herhangi biri olumsuz ise diğer durum kontrol edilmeden negatif değerlendirme yapılmaldır.",
       "SectionName":"muhasebe ve ofis "
    },
    {
       "QuestionId":24,
       "QuestionName":"Çelik kasada ki bozuk paralar tam mı ? ( Çelik kasadaki paralar sayılmalı.",
       "SectionName":"muhasebe ve ofis "
    },
    {
       "QuestionId":25,
       "QuestionName":"Civil radyo, aktif olarak kullanılıyor mu ? (Ezan saatleri haricinde radyo sürekli çalışıyor olmalı.)",
       "SectionName":"kasa işlemleri"
    },
    {
       "QuestionId":26,
       "QuestionName":"Defolu ürünler düzenli gönderilmiş mi ? (Defolular sayılacak 35 adetten fazla olmamalı. )",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":27,
       "QuestionName":"Depoda ağır koliler alt raflarda mı?(Ağır ürünler üst raflarda olmamalı.Alt iki rafta olmalı)",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":28,
       "QuestionName":"Depoda raflar sabitlenmiş mi? (Raflar kontrol edilerek bakılır.)",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":29,
       "QuestionName":"Depoda risk oluşturacak ağır malzemeler alt raflarda mı?(Poşetler ve hediye paketler alt üç (3) rafta olmalı)",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":30,
       "QuestionName":"Depodaki tüm ürünlerden reyonlarda mevcut mu? ( Depodan 10 adet ürün alınarak sistem ile kontrol edilip kıyaslanır.10 üründen 3 tane hatalı olduğunda olumsuz not verilir.)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":31,
       "QuestionName":"Depoların güvenliği için kapılar kapalı ve kameralar çalışır durumunda mı? (Depo kapıların üstünde ‘GİRİLMEZ’ vb. uyarı yazısı var mıdır?)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":32,
       "QuestionName":"Dış cephe temizliği yapılmış mı ? ( vitrin camı,mağaza önü)",
       "SectionName":"görsel "
    },
    {
       "QuestionId":33,
       "QuestionName":"Dış kompozitler temiz mi? (Kompozit üzerlerinde iş ilanları vb. duyurular temizlenmeli.)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":34,
       "QuestionName":"Elektrik pano kapıları kilitli mi ? (Yetkisiz kişiler panoya müdahale etmemeli )",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":35,
       "QuestionName":"Elektrik panolarında kaçak akım rolesi var mıdır ? (Katlarda veya ana panoda olmalı.)",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":36,
       "QuestionName":"Elektrik panosu önlerinde yalıtım paspasları var mı ? (Yalıtım paspası eni elektrik panosunun eni kadar , genişliği de 60 cm olmalı.)",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":37,
       "QuestionName":"Elektrik panosunda elektrik işaret ve uyarı levhası var mı ? (Tüm katlardaki panolarda ve genel pano oda kapılarında Tehlike ve Yüksek voltaj )",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":38,
       "QuestionName":"Elektrik panosunun etrafı yönetmelikte belirtildiği şekilde boş ve temiz mi?",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":39,
       "QuestionName":"Elektrik panosunun yakınında korbondioksit tüpü var mı?(Tüpler elektrik panosunun yanında olmayacak.Yangın çıktığında kolay alınabilecek yerde olmalı)",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":40,
       "QuestionName":"Elektronik ürünlerin fiyatları güncel mi?(Tüm ürün  güncel fiyatlarla teşhir edilmeli)",
       "SectionName":"görsel "
    },
    {
       "QuestionId":41,
       "QuestionName":"Erkek ayakkabılarında,panduflarda ve terlikler de alarm takılı mı? (30 ürüne bakılıp (%10) 3 tane üründe alarm takılı değilse ise olumsuz not verilir.)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":42,
       "QuestionName":"Erkek ürünlerinde alarm takılı mı? (100 ürüne bakılıp (%10) en az 10 ve üzeri üründe alarm takılı değilse olumsuz not verilir.)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":43,
       "QuestionName":"Erkek ürünlerinde askılama doğru yapılmış mı?(Civil askısı olmalı, yaş gruplarına göre doğru askı takılmalı ve tek tip olmalı.100 ürüne bakılıp (%10) en az 10 ve üzeri üründe askılama doğru değilse ise olumsuz not verilir.)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":44,
       "QuestionName":"Erkek ürünlerinde etiketleme doğru yapılmış mı ? ( İç barkot ile dış barkot kontrolü yapılarak uyumları kontrol edilir.100 ürüne bakılıp (%10) en az 10 ve üzeri üründe iç barkot ile dış barkot uyumlu değilse olumsuz not verilir.)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":45,
       "QuestionName":"Erkek ürünlerinde fiyat değişiklikleri uygulanmış mı ? (El terminali ile kontrol edilir 100 ürüne bakılır (%10) en az 10 ve üzeri ürünlerde fiyat değişikliği yapılmadıysa olumsuz not verilir.Aynı gün gelen fiyat değişikliği dahil değildir.)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":46,
       "QuestionName":"Haftanın ürünü kampanyasındaki ürünler tam olarak sergilenmiş mi ? ( Merkezin belirlediği kampanya ürünlerinin hepsi eksiksiz olmalı)",
       "SectionName":"görsel "
    },
    {
       "QuestionId":47,
       "QuestionName":"Her reyondan ürün alıp stok kontrolleri yapıldı mı ? Yapılan kontrollerin sonucu doğru mu ? (10 ürün alınarak mağazası sayılır, sistem ile kontrol edilip kıyaslanır. 10 üründen 3 tane hatalı olduğunda olumsuz not verilir.)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":48,
       "QuestionName":"Hırsız alarm sistemi çalışıyor mu? Depodakiler dahil çalışmalı.(Sistem şifre girilerek kontrol edilir ve kayıtlı numaraya arama yapıyor mu aranan kişi mağaza personeli olmalı.Alarm sistemi çalmalı.) edilir ve kayıtlı numaraya arama yapıyor mu aranan kişi mağaza personeli olmalı.)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":49,
       "QuestionName":"Jeneratörün etrafı boş ve temiz mi ? (Tamamen boş olmalı.)",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":50,
       "QuestionName":"Jeneratörün periyodik bakımları yapılıyor mu?(Bakım formları kayıt altına alınmış mı kontrol edilerek bakılır.Bakımlar 6 ayda bir yapılmalı)",
       "SectionName":"muhasebe ve ofis "
    },
    {
       "QuestionId":51,
       "QuestionName":"Jeneratörün suyu tam mı ? ( Kapak açılarak kontrol edilir.)",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":52,
       "QuestionName":"Jeneratörün yağı tam mı ? (Yağ çubuğu çıkartılarak kontrol edilir.)",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":53,
       "QuestionName":"Jeneratörünün yakıtı yarıdan fazla mı ? (Yakıt göstergesine bakılır az ise tamamlatılır.)",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":54,
       "QuestionName":"Kabinlerde askılık var mı ? (Kabinlerdeki askılar kırık olmamalı ve kullanılabilir olmalıdır)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":55,
       "QuestionName":"Kabinlerin ışıkları çalışıyor mu ?",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":56,
       "QuestionName":"Kabinlerin kapı kilitleri çalışıyor mu ?",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":57,
       "QuestionName":"Kamera açıları doğru yönde mi ? (Kameralar ayrı ayrı kasa çekmecelerini ve müşteriyi göstermeli,kamera görüntüleri net olmalı.)",
       "SectionName":"kasa işlemleri"
    },
    {
       "QuestionId":58,
       "QuestionName":"Kamera saatleri ile TSİ ile uyumlu olmalıdır.( Saat ve dakika göstergesi aynı olmalıdır. Saniye göstergesi baz alınmayacaktır) ",
       "SectionName":"kasa işlemleri"
    },
    {
       "QuestionId":59,
       "QuestionName":"Kampanyalı ürünler belirlenen yerde sergilenmiş mi ?(Birinci öncelik mağaza girişi,girişte uygun yer yoksa,kasa önleri ve reyonların girişlerinde sergilenmeli)",
       "SectionName":"görsel "
    },
    {
       "QuestionId":60,
       "QuestionName":"Kampanyalı ürünlerde çarpılı etiket çalışması uygulanmış mı ? ( Eski fiyat üzerine çarpı, altında kampanyalı fiyatı olmalı)",
       "SectionName":"görsel "
    },
    {
       "QuestionId":61,
       "QuestionName":"Kapı ve kaçış yollarını gösteren acil durum levhaları uygun yerlere yerleştirilmiş, yangın merdivenin de ve kaçış yollarında ışıklandırma sağlanmış mı?(Exit tabelaları üzerinde bulunan test düğmelerine basılmalı ışık sönmediyse sağlam olduğu söndü ise de arızalı olduğu anlaşılmalıdır)",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":62,
       "QuestionName":"Karşılama masalarında uygun ve cazip ürünler sergilenmiş mi? (Ürün yönetimi ve Satın alma departmanından gelen aylık karşılama stant ürünleri sergileniyor mu 15 adet ürün kontrolü yapılmalıdır.Ürün yönetimin belirlemiş olduğu ürünlerden kalmadıysa 49,90 geçmeyecek şekilde ürün koyulmalıdır)",
       "SectionName":"görsel "
    },
    {
       "QuestionId":63,
       "QuestionName":"Karşılama masalarındaki ürünler dolu mu?(Raf aralıklarında,yaz ürünlerinde üst üste 6 adetten az ürün olmamalı,kış ürünlerinde ise en az üst üste 3 adet olmalı.Üst raf da dahil ürün sergilenmeli)",
       "SectionName":"görsel "
    },
    {
       "QuestionId":64,
       "QuestionName":"Karşılama standı ve masasında fiyat çalışmaları yapılmış mı ? ( Calibri yazı stili, masa ve stantlarda toplam 3 adet fiyat çerçevesi olmalı)",
       "SectionName":"görsel "
    },
    {
       "QuestionId":65,
       "QuestionName":"Kasa da bulunan deaktivatör ( kağıt alarm iptal) cihazı çalışır durumda ve uyarı sesi aktif olmalıdır ?",
       "SectionName":"kasa işlemleri"
    },
    {
       "QuestionId":66,
       "QuestionName":"Kasa defteri günlük dolduruyor mu ? (Bekletilip ay sonu doldurulmamalı.)",
       "SectionName":"kasa işlemleri"
    },
    {
       "QuestionId":67,
       "QuestionName":"Kasa duvarında asılması gereken resmi evraklar asılmış mı ? ( Vergi levhası,iş yeri ruhsatı,faaliyet belgesi )",
       "SectionName":"kasa işlemleri"
    },
    {
       "QuestionId":68,
       "QuestionName":"Kasa kapanışları net mi ? (Geriye dönük en son denetim tarihinden şubenin ciro toplamı 1000\/0,5 oranı baz alınarak eksi ve artılar kontrol edilir.)",
       "SectionName":"kasa işlemleri"
    },
    {
       "QuestionId":69,
       "QuestionName":"Kasa nakit akış formları imzalı mı ? (Kasiyerler ve mağaza yetkilisi tarafından günlük isim ve imzalar atılmış olmalı .Geriye dönük 1 aylık  bakılır. )",
       "SectionName":"kasa işlemleri"
    },
    {
       "QuestionId":70,
       "QuestionName":"Kasa önündeki ıslak mendillerin fiyat çıtalarına fiyatları koyulmuş mu ? (Her Ürün için fiyatlandırma yapılmış olmalıdır.)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":71,
       "QuestionName":"Kasa önündeki oyuncakların alarmları vurulmuş ? (30 ürüne bakılıp (%10) en az 3 ve üzeri üründelerde alarm yoksa olumsuz not verilir.)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":72,
       "QuestionName":"Kasa önündeki oyuncakların fiyat çıtalarına fiyatları koyulmuş mu ? (Her Ürün için fiyatlandırma yapılmış olmalıdır.)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":73,
       "QuestionName":"Kasa personeli kasa da  müşteri için karşılama ve uğurlama cümlelerini kullanıyor mu?",
       "SectionName":"kasa işlemleri"
    },
    {
       "QuestionId":74,
       "QuestionName":"Kasalar ayrı mı ?",
       "SectionName":"kasa işlemleri"
    },
    {
       "QuestionId":75,
       "QuestionName":"Kasaya giren nakit para ile sistem tutuyor mu ? (Kasalar tek tek sayılmalı)",
       "SectionName":"kasa işlemleri"
    },
    {
       "QuestionId":76,
       "QuestionName":"Kasiyer,her müşteriden Adı-Soyadı alarak sisteme işliyor mu ? ( Müşterimizin daha önceden kaydı var ise soruda belirtilen maddelerin güncellenmesi gerekmektedir.)",
       "SectionName":"kasa işlemleri"
    },
    {
       "QuestionId":77,
       "QuestionName":"Kız ayakkabılarında,panduflarda ve terlikler de alarm takılı mı? (30 ürüne bakılıp (%10) 3 tane üründe alarm takılı değilse ise olumsuz not verilir.)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":78,
       "QuestionName":"Kız ürünlerinde alarm takılı mı? (100 ürüne bakılıp (%10) en az 10 ve üzeri üründe alarm takılı değilse olumsuz not verilir.)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":79,
       "QuestionName":"Kız ürünlerinde askılama doğru yapılmış mı?(Civil askısı olmalı, yaş gruplarına göre doğru askı takılmalı ve tek tip olmalı.100 ürüne bakılıp (%10) en az 10 ve üzeri üründe askılama doğru değilse ise olumsuz not verilir.)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":80,
       "QuestionName":"Kız ürünlerinde etiketleme doğru yapılmış mı ? ( İç barkot ile dış barkot kontrolü yapılarak uyumları kontrol edilir.100 ürüne bakılıp (%10) en az 10 ve üzeri üründe iç barkot ile dış barkot uyumlu değilse olumsuz not verilir.)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":81,
       "QuestionName":"Kız ürünlerinde fiyat değişiklikleri uygulanmış mı ? (El terminali ile kontrol edilir 100 ürüne bakılır (%10) en az 10 ve üzeri ürünlerde fiyat değişikliği yapılmadıysa olumsuz not verilir.Aynı gün gelen fiyat değişikliği dahil değildir.)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":82,
       "QuestionName":"Klimaların yazlık ve kışlık bakımları yapılmış mı ? ( Bakım formları kayıt altına alınmalı.Bakımlar 6 ayda bir yapılmalı)",
       "SectionName":"muhasebe ve ofis "
    },
    {
       "QuestionId":83,
       "QuestionName":"Kozmetik ürünlerinde alarm takılı mı? (30 ürüne bakılıp (%10) en az 3 ve üzeri üründe alarm takılı değilse olumsuz not verilir.)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":84,
       "QuestionName":"Mağaza içinde yapılan kuleler belirtilen standartlarda mı?(Maksimum 130 cm minimum 100 cm tuğla örme stilinde olmalı)",
       "SectionName":"görsel "
    },
    {
       "QuestionId":85,
       "QuestionName":"Mağaza ışıklarının tamamı çalışır durumda mı ? (Magazada 3 ve üzeri fazla yanmayan ışık varsa olumsuz kanaat verilir.)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":86,
       "QuestionName":"Mağaza mescit ve wc temizliği yapılmış mı? (Sıvı sabun ve kağıtların kontrolü yapılmalı)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":87,
       "QuestionName":"Mağaza müdürü tarafından günlük ilk 45 dakika uygulaması gerçekleştiriliyor mu ? ( Mağaza yönetimi tarafından günlük ilk 45 dakikada tüm mağaza denetlenip, tarih ,isim ve  imzalar atılıp notlar kayıt altına alınıp,geriye dönük en az 1 ay notlar saklanmalı.)",
       "SectionName":"muhasebe ve ofis "
    },
    {
       "QuestionId":88,
       "QuestionName":"Mağaza ve depo genelinde prizler de emniyet kilidi var mı ? ( Çocuklar için tehlike oluşturmayacak şekilde çocuk emniyet kilidi olmalı)",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":89,
       "QuestionName":"Mağaza ve depo genelinde tüm elektrik kabloları sağlam mı ? ( Ucu açık hasar görmüş elektrik kablosu olmamalı ve yetişkin bir insanın ulaşacağı mesafede olmamalı)",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":90,
       "QuestionName":"Mağaza ve depoda seyyar merdivenler güvenli kullanıma uygun mu ? (Sağlam olamayan kırık,sallanan merdivenler kullanılmamalı. )",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":91,
       "QuestionName":"Mağazada vardiya listesi güncel ve asılı mı? (Vardiya listeleri ortak kullanım alanlarında ve müdür odasına asılı ve imzalı olmalı.)",
       "SectionName":"iş kanunu ve çalışma"
    },
    {
       "QuestionId":92,
       "QuestionName":"Mağazada ve kabinlerde olması gereken kurumsal uyarı yazıları var mi?( Bu is yeri 24 saat kamera ile izlenmektedir ve kabinlerde kıymetli eşyanızı bırakmayın her kabinin içinde olmalı)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":93,
       "QuestionName":"Mağazamızda İlk Yardım Eğitimi alan var mı ? (En az 1 kişide olması,Alınan bu sertifika güncel mi ?)",
       "SectionName":"iş kanunu ve çalışma"
    },
    {
       "QuestionId":94,
       "QuestionName":"Mağazaya sevk olunan ürünler 2 gün içersinde sayılmış ve reyonlara açılmış mı? (01 Ocakta teslim alınan ürünler 3 Ocak 15:00 a kadar reyonlara gönderilmiş olmalıdır)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":95,
       "QuestionName":"Mama ürünlerinde alarm takılı mı? (30 ürüne bakılıp (%10) en az 3 ve üzeri  üründe alarm takılı değilse  olumsuz not verilir.)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":96,
       "QuestionName":"Mankenler ve manken kaideleri temiz mi? Zarar görmüşler mi?(Mankenlerin kaideleri temiz olmalı, mankenler kırık olmamalı ve göze çirkin görünmemeli)",
       "SectionName":"görsel "
    },
    {
       "QuestionId":97,
       "QuestionName":"Merdiven çevresinde ki küpeşteler sağlam mı?(Küpeşteler 5 cm'den fazla sallanmamalı.Depolar dahil kontrol edilir)",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":98,
       "QuestionName":"Merdiven korkuluklarının çevresi çocukların tırmanabileceği koltuk,puf vb. malzemelerden arındırılmış mı?(Korkuluk kenarlarına koyulan kule vb. ürünler üzerlerine basıp çıkabilecek durumda olmamalı)",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":99,
       "QuestionName":"Merdivenlerde kaydırmaz bant var mı?(Bantlar yıpranmış özelliğini kaybetmiş olmamalı,merdivenin uç kısmına yapıştırılmalı.Depo dahil kontrol edilir)",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":100,
       "QuestionName":"Merkezden gelen avans kapama forumları imzalı mı ? ( Merkezden alınan avansların kapanışlarındaki forumlar mağaza müdürü tarafından imzalanmalıdır)",
       "SectionName":"muhasebe ve ofis "
    },
    {
       "QuestionId":101,
       "QuestionName":"Merkezin belirlediği kampanyalar şubede eksiksiz uygulanmış mı ? ( Tüm kampanyalı ürün listeleri alınarak kontrol edilir)",
       "SectionName":"görsel "
    },
    {
       "QuestionId":102,
       "QuestionName":"Mesai saati içinde izin almış personele izin formu doldurtulmuş mu ? (Özlük dosyalarından kontrol)",
       "SectionName":"iş kanunu ve çalışma"
    },
    {
       "QuestionId":103,
       "QuestionName":"Molalarda kasa çekmeceleri kilitli mi ? (Çekmece kilitleri kontrol edilir, molalarda kasiyer kendi kasasını kilitleyerek anahtarı üzerinde almalıdır.",
       "SectionName":"kasa işlemleri"
    },
    {
       "QuestionId":104,
       "QuestionName":"Müşteriye ait servise gönderilecek olan ürünlerin ve servisten gelen ürünlerin alanı olmalı ve işlemleri yapılmalı.(3 gün içinde servise veya müşteriye teslim edilmeli)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":105,
       "QuestionName":"Oyuncak ürünlerinde alarm takılı mı? (30 ürüne bakılıp (%10) en az 3 ve üzeri üründe alarm takılı değilse  olumsuz not verilir.)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":106,
       "QuestionName":"Patiklerde,ilk adım ayakkabılarında ve terlikler de alarm takılı mı? (30 ürüne bakılıp (%10) 3 tane üründe alarm takılı değilse olumsuz not verilir.)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":107,
       "QuestionName":"Personel kıyafetleri ve yaka kartları yönetmeliğe uygun mu ?(Mağazada çalışan her personelde yaka kartı ve uniforma olmalı.)",
       "SectionName":"iş kanunu ve çalışma"
    },
    {
       "QuestionId":108,
       "QuestionName":"Personel satışları yönetmeliğe uygun mu ? (Satışlar ve iadeler müdür kasasından yapılmalı, en son denetim tarihinden itibaren bakılır, her personel kendi kotasından işlem yapmalı.)",
       "SectionName":"kasa işlemleri"
    },
    {
       "QuestionId":109,
       "QuestionName":"Personellerin hepsi iş güvenliği eğitimini tamamlamış sertfifikasını almış mı ? Yeni işe giren personellerin ilk 10 gün içinde eğitimi tamamlamış sertifikasını almış olmalı, Tüm personeller için sertifikalar 3 yılda bir yenilenmelidir) ",
       "SectionName":"iş kanunu ve çalışma"
    },
    {
       "QuestionId":110,
       "QuestionName":"Raf ve dikmelerdeki tüm ürünler ambalajlı mı ? (Depodaki tüm ürünlerde ambalaj olmalı.)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":111,
       "QuestionName":"Reyon üzerlerindeki cnc yazılar tam mı ürünlerle yazılar uyumlu mu ? ( Reyon üzerlerinde cnc yazılar olmalı, ürünler ile reyon üzerindeki yazılar birbirini tutmalı)",
       "SectionName":"görsel "
    },
    {
       "QuestionId":112,
       "QuestionName":"Reyonlarda bulunan tüm gıda ürünlerin son kullanma tarihleri uygun mu ? ( 30 adet ürün kontrol edilir  ve hata  olmamalıdır. Ayrıca Son Kullanma Tarihine en az 30 günden fazla olmalı)?",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":113,
       "QuestionName":"Rutin temizlik çizelgesi günlük kontrol ediliyor mu ? ( Bay - Bayan Wc, Bebek bakım odası ve mescit vb. gibi yerlerin günlük temizliği yapılmış ve kapı arkasında bulunan listeler güncel olarak imzalanmış olmalı.)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":114,
       "QuestionName":"Sahte para cihazları çalışır durumda mı? (3 deneme yapılmalı.)",
       "SectionName":"kasa işlemleri"
    },
    {
       "QuestionId":115,
       "QuestionName":"Sisteme geçen pos tutarı ile hesaba geçen tutar tutuyor mu ?",
       "SectionName":"kasa işlemleri"
    },
    {
       "QuestionId":116,
       "QuestionName":"Sisteme yazılan nakit ile bankaya yatan tutuyor mu ? (Sistem ile teslim tutanağı karşılaştırılır.)",
       "SectionName":"muhasebe ve ofis "
    },
    {
       "QuestionId":117,
       "QuestionName":"Stant düzeni ve kule teşhirleri müşteri yürüyüş-geçiş alanına sahip mi?(Geçiş alanları en az 100 cm olması gereklidir)",
       "SectionName":"görsel "
    },
    {
       "QuestionId":118,
       "QuestionName":"Şube alarm antenleri sağlıklı çalışıyor mu ? (Antenler bozuk olmamalı, kapı antenlerine yakın alarmlı ürün bulunmamalı.)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":119,
       "QuestionName":"Şubede ilk yardım dolabı var mı ve dolap içinde uygun malzeme var mı ? (Deposu dışarıda ayrı ise ayrıca dolap koyulmalı- Sargıbezi-Tentürdiot -Yara bandı-Pamuk -Çengelli iğne-Cımbız -Keskin makas -İlk yardım kitapçığı -Oksijenli Su)",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":120,
       "QuestionName":"Şubede kaygan zemin uyarı levhası var mı ? (Her reyon için birer adet olmalı, Tek katlı mağazalarda ise 2 adet olmalı)",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":121,
       "QuestionName":"Tabela ışıkları yanıyor mu ? (Görselleri aydınlatan  Civil logosu ,spotlar ve projektörler dahil kontrol edilir.)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":122,
       "QuestionName":"Tüm kameralar çalışır durumda mı ? (Mağaza da bulunan tüm DVR cihazlarında görüntü olmalıdır ve DVR cihazları geçmişe dönük kayıt yapmalıdır ) ",
       "SectionName":"kasa işlemleri"
    },
    {
       "QuestionId":123,
       "QuestionName":"Tüm klimalar çalışır durumda mı ? (Hepsi Kontrol edilir.)",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":124,
       "QuestionName":"Tüm müşterilerin almış olduğu ürünler deaktivatör ( kağıt alarm iptal cihazına) okutuluyor mu?(10 müşteri takip edilir, tamamı okutulmalıdır)",
       "SectionName":"kasa işlemleri"
    },
    {
       "QuestionId":125,
       "QuestionName":"Tüm personelin personel yönetmeliği ve görev tanımları imzalıtılmış mı ? (Mağaza müdürü ve personelin isim ve imzaları atılmış olmalı ,personel özlük dosyasında bulundurmalı.)",
       "SectionName":"iş kanunu ve çalışma"
    },
    {
       "QuestionId":126,
       "QuestionName":"Ürün iadeleri sistem ile tutarlı mı ? (İade gider pusulalarının sayısı sistemdeki sayı ile karşılaştırılır.)",
       "SectionName":"kasa işlemleri"
    },
    {
       "QuestionId":127,
       "QuestionName":"Ürünler iç barkot okutularak satış yapılmış mı ? (İç barkot satış kontrolü yapılır. 10 tekstil ürününün satışı incelenir. Tamamı iç barkottan okutularak satılmalıdır)",
       "SectionName":"kasa işlemleri"
    },
    {
       "QuestionId":128,
       "QuestionName":"Ürünlerde alarm doğru uygulanmış mı?(Ürüne karşısından bakıldığındaÜst Grup sağ alta,Alt Grupta arka belden,mantar dışarıda olacak ,ayakkabılarda sağ tek teşhirde olmalı,sol teki alarmlı kutusunda olmalı,kağıt alarmlar ürünün arka yüzüne,ürün özelliklerini kapatmayacak şekilde vurulmalı(5 ve üzeri y",
       "SectionName":"operasyon"
    },
    {
       "QuestionId":129,
       "QuestionName":"Vitrin içi mankenlerde doğru kombinler yapılmış mı?(Merkez tasarımın gönderdiği resimler baz alınarak kontrol edilir)",
       "SectionName":"görsel "
    },
    {
       "QuestionId":130,
       "QuestionName":"Vitrin içindeki ürünlerin fiyat çalışmaları yapılmış mı?(Vitrin fiyat çerçevesinde fiyatlar uygulanmış olmalı)",
       "SectionName":"görsel "
    },
    {
       "QuestionId":131,
       "QuestionName":"Vitrin ışıkları yanıyor mu ?(Tüm spotlar,saylangozlar yanmalı yönleri mankenlere bakmalı)",
       "SectionName":"görsel "
    },
    {
       "QuestionId":132,
       "QuestionName":"Vitrin teması istenen şekilde uygulanmış mı?(Merkez tasarımın gönderdiği resimlere bakılır,birebir uygulanmış olduğu kontrol edilir)",
       "SectionName":"görsel "
    },
    {
       "QuestionId":133,
       "QuestionName":"Vitrin temizliği yapılmış mı?(İç yer ve cam temiz olmalı,ürünlerin üzerinde toz olmamalı)",
       "SectionName":"görsel "
    },
    {
       "QuestionId":134,
       "QuestionName":"Vitrinler ve kasa arkasındaki TV ler çalısıyor mu?(Guncel reklamlar donuyor olmalı)",
       "SectionName":"görsel "
    },
    {
       "QuestionId":135,
       "QuestionName":"Yangın alarm cihazı (Siren-Butonlar vs.) çalışır durumda olmalı depolar da dahil.(Bir tane alarm cihazı düğmesine basılarak denenir.Avm mağazalarında deneme yapılmaz).",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":136,
       "QuestionName":"Yangın merdiveni,acil çıkışlar her zaman açılabilir ve kullanılabilir durumda mı?(Yangın koridorunda kaçışa engel teşkil eden hiçbir malzeme bulunmamalı.Yangın kapısının panik bar kolu olmalı ve açılmaya engel bir kilit olmamalı)",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":137,
       "QuestionName":"Yangın tüpleri görünür yerde, önleri açık ve işaret levhaları var mı?(Tüpler Ürünlerin aralarında kaybolmamalı işaret levhaları fosforlu ve yerde tüpü gösterir olmalı,depolarda dahil kontrol edilir.)",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":138,
       "QuestionName":"Yangın tüplerinin basınç saati ibresi yeşil alan üzerinde mi?(İbre kırmızı üzerindeyse doldurulması gerekmektedir)",
       "SectionName":"iş sağlığı ve güvenliği"
    },
    {
       "QuestionId":139,
       "QuestionName":"Yıllık izin ve çizelgeleri imzalı ve İ.K. Departmanına maili atıldı mı ? (Yıllık izini hak edip izin kullanmış personellere izmalatılmalı.Yıllık izin istek formu onayı da geçerli olmaktadır.Personel özlük dosyalarından rastgele 3 adet kontrolü yapılmalıdır)",
       "SectionName":"iş kanunu ve çalışma"
    },
    {
       "QuestionId":140,
       "QuestionName":"Zimmet formunda bulunan bilgi işlem demirbaş malzemeleri tam mı ? (Bilgi işlemden mağazanın demirbaş listesi istenerek kontrol edilir.)",
       "SectionName":"muhasebe ve ofis "
    }
 ]