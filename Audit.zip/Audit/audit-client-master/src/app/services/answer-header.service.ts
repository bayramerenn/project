import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { environment } from "src/environments/environment";
import { AnswerHeader } from "../entities/answer-header";
import { HeaderWizard } from "../entities/header-wizard";
import { PendingSurvey } from "../entities/pending-survey";
import { Result } from "../entities/result";

@Injectable({
  providedIn: "root",
})
export class AnswerHeaderService {
  public storeId: number;
  public questionGroupId: number;

  private apiUrl: string = environment.apiUrl;
  constructor(private http: HttpClient) {}

  public createAnswerHeader(
    answerHeader: AnswerHeader
  ): Observable<AnswerHeader> {
    return this.http.post<AnswerHeader>(
      this.apiUrl + "/Answers/CreateAnswerHeader",
      answerHeader
    );
  }

  public deleteAnswer(answerHeaderId: number): Observable<Result<any>> {
    var params = new HttpParams().set(
      "answerHeaderId",
      answerHeaderId.toString()
    );
    return this.http.delete<Result<any>>(this.apiUrl + "/Answers", { params });
  }
  public getPendingSurveys(answerIds: number[]): Observable<PendingSurvey[]> {
    return this.http.post<PendingSurvey[]>(
      this.apiUrl + "/Answers/PendingSurveys",
      answerIds
    );
  }

  public CreateAnswerHeaderPhoto(file: any): Observable<Result<any>> {
    return this.http.post<Result<any>>(
      this.apiUrl + "/Answers/AnswerHeaderPhotosCreate",
      file
    );
  }

  public DeleteAnswerHeaderPhoto(fileLame: string): Observable<Result<any>> {
    var params = new HttpParams().set("fileName", fileLame);

    return this.http.delete<Result<any>>(
      this.apiUrl + "/Answers/AnswerHeaderPhotosDelete",
      { params }
    );
  }

  public UpdateAnswerWizard(headerWizard:HeaderWizard): Observable<Result<any>> {
    

    return this.http.put<Result<any>>(
      this.apiUrl + "/Answers/HeaderWizardUpdate",
      headerWizard
    );
  }

  public RemoveImagePathReset(answerHeaderId:number){
    
    var params = new HttpParams().set("answerHeaderId",answerHeaderId.toString())
     this.http.delete(this.apiUrl +"/Answers/ImagePathReset",{params}).subscribe();
    //  this.http.(
    //   this.apiUrl + "/Answers/HeaderWizardUpdate",
    //   headerWizard
    // );
  }
}
