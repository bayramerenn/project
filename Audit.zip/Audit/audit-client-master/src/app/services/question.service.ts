import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { BehaviorSubject, Observable } from "rxjs";
import { environment } from "src/environments/environment";
import { Question } from "../entities/question";
import { QuestionGroup } from "../entities/question-group";

@Injectable({
  providedIn: "root",
})
export class QuestionService {
  private apiUrl: string = environment.apiUrl;
  

  constructor(private http: HttpClient) {}

  getQuestionGroupsByStoreId(storeId: number): Observable<QuestionGroup[]> {
    const params = new HttpParams()
    .set(
      "storeId",
      storeId.toString());
    return this.http.get<QuestionGroup[]>(this.apiUrl + "/questiongroups", {
      params,
    });
  }

  getQuestion(questionGroupId: number):Observable<Question[]> {
    const params = new HttpParams().set(
      "questionGroupId",
      questionGroupId.toString()
    );

    return this.http.get<Question[]>(this.apiUrl + "/questions", { params });
     
  }
}
