import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment.prod';
import { Result } from '../entities/result';


@Injectable({
  providedIn: 'root'
})
export class AnswerLineService {
  private apiUrl:string = environment.apiUrl;
  constructor(private http:HttpClient) { }

  createAnswerLine(answerLines:any[]):Observable<Result<any>>{
    return this.http.post<Result<any>>(this.apiUrl+'/Answers/CreateAnswerLine',answerLines)
  }

  updateAnswerLine(answerLines:any[]):Observable<Result<any>>{
    return this.http.post<Result<any>>(this.apiUrl+'/Answers/UpdateAnswerLine',answerLines)
  }
  
}
