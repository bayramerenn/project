import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { NebimPersonel } from '../entities/nebim-personel';

@Injectable({
  providedIn: 'root'
})
export class PersonelService {
  
  private apiUrl:string = environment.apiUrl;
  constructor(private http:HttpClient) { }

  public getNebimPersonel(storeCode:string):Observable<NebimPersonel[]>{

      var params = new HttpParams().set('storeCode',storeCode)
      return this.http.get<NebimPersonel[]>(this.apiUrl+'/Personels/GetPersonels',{params})
  }
}
