import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { environment } from 'src/environments/environment';
import { Result } from '../entities/result';
import { SmsPoolDto } from '../entities/sms-pool-dto';
import { SMSDto } from '../entities/smsDto';

@Injectable({
  providedIn: 'root'
})
export class SmsSendService {

  private apiUrl:string = environment.apiUrl;
  constructor(private http:HttpClient) { }

  sendSms(smsPoolDto:SmsPoolDto):Observable<Result<SMSDto>>{
    return this.http.post<Result<SMSDto>>(this.apiUrl+'/Answers/Sms',smsPoolDto);
  }
}
