﻿using Core.Utilities.Results;
using Entities.Dtos;
using Entities.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Business.Abstract
{
    public interface IAnswerHeaderService
    {
        Task<IDataResult<AnswerHeader>> CreateAnswerHeaderAsync(AnswerHeader answerHeader);

        Task<IResult> DeleteAnswerHeaderAsync(int answerHeaderId);

        Task<AnswerHeader> GetAnswerHeaderAsync(int answerHeaderId);

        Task UpdateAnswerHeaderAsync(AnswerHeader answerHeader);

        public Task<IList<PendingSurvey>> GetPendingSurveysAsync(int[] headerIds);

        Task<Result> UpdateAnswerHeaderPhotoAsync(int answerHeaderId, string imagePath);
        Task<Result> DeleteAnswerHeaderPhotoAsync(int answerHeaderId, string imageName);
        Task<string> GetAnswerHeaderImagePathAsync(int answerHeaderId);
        Task<IResult> UpdateHeaderWizardDtoAsync(HeaderWizardDto headerWizardDto);
        Task<IResult> RemoveImagePathReset(int answerHeaderId);
    }
}