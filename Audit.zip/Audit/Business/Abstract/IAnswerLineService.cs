﻿using Core.Utilities.Results;
using Entities.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Business.Abstract
{
    public interface IAnswerLineService
    {
        Task<IResult> CreateAnswerRangeLineAsync(List<AnswerLine> answerLine);
        Task<IResult> UpdateAnswerLineRangeAsync(List<AnswerLine> answerLine);
    }
}