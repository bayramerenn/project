﻿using Core.Utilities.Results;
using Entities.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Business.Abstract
{
    public interface IPersonelService
    {
        Task<IDataResult<List<NebimPersonel>>> GetNebimPersonel(string storeCode);
    }
}
