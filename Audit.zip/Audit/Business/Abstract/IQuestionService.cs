﻿using Entities.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Business.Abstract
{
    public interface IQuestionService
    {
        Task<IList<AssignedQuestions>> GetQuestionsAsync(int questionGroupId);
        Task<IList<Question>> GetQuestionAll();
    }
}
