﻿using Core.Utilities.Results;
using Entities.Dtos;
using Entities.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Business.Abstract
{
    public interface ISMSPoolService
    {
        Task<IDataResult<SMSDto>> CreateSmsAsync(SMSPool smsPool);
    }
}
