﻿using Business.Abstract;
using DataAccess.Abstract.UnitOfWork;
using Entities.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Business.Concrete
{
    public class StoreService : IStoreService
    {
        private readonly IUnitOfWork _unitOfWork;

        public StoreService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<List<Store>> GetStoresAsync()
        {
            return await _unitOfWork.StoreDal.GetStoresAsync();
        }
    }
}