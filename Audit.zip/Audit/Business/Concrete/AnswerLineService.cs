﻿using Business.Abstract;
using Business.Constants;
using Core.Utilities.Results;
using DataAccess.Abstract.UnitOfWork;
using Entities.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Business.Concrete
{
    public class AnswerLineService : IAnswerLineService
    {
        private readonly IUnitOfWork _unitOfWork;

        public AnswerLineService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public async Task<IResult> CreateAnswerRangeLineAsync(List<AnswerLine> answerLine)
        {
            try
            {
                await _unitOfWork.AnswerLineDal.AddRangeAsync(answerLine);
                await _unitOfWork.CommitAsync();
                return new SuccessResult(Messages.AnswerLineSuccessCreated);
            }
            catch (Exception ex)
            {
                return new ErrorResult(Messages.AnswerLineErrorDeleted);
                
            }
        }

        public async Task<IResult> UpdateAnswerLineRangeAsync(List<AnswerLine> answerLine)
        {
            try
            {
                 _unitOfWork.AnswerLineDal.UpdateRange(answerLine);
                await _unitOfWork.CommitAsync();
                return new SuccessResult(Messages.AnswerLineSuccessCreated);
            }
            catch (Exception ex)
            {
                return new ErrorResult(Messages.AnswerLineErrorDeleted);

            }
        }
    }
}
