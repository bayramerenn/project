﻿using Business.Abstract;
using DataAccess.Abstract.UnitOfWork;
using Entities.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Business.Concrete
{
    public class QuestionGroupService : IQuestionGroupService
    {
        private readonly IUnitOfWork _unitOfWork;

        public QuestionGroupService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<IList<QuestionGroup>> GetQuestionGroupsAsync(int storeId)
        {
            return await _unitOfWork.QuestionGroupDal.GetQuestionGroupsAsync(storeId);
        }
    }
}
