﻿using Business.Abstract;
using Core.Utilities.Results;
using DataAccess.Concrete.EntityFramework.Context;
using Entities.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Business.Concrete
{
    public class PersonelService : IPersonelService
    {
        private readonly CivilDbContext _context;

        public PersonelService(CivilDbContext context)
        {
            _context = context;
        }

        public async Task<IDataResult<List<NebimPersonel>>> GetNebimPersonel(string storeCode)
        {
            try
            {
                var result = await _context.NebimPersonel.FromSqlRaw($"EXEC dbo.sp_audit_GetPersonelByWorkPlaceCode @WorkPlaceCode = N'{storeCode}'").AsNoTracking().ToListAsync();

                return new SuccessDataResult<List<NebimPersonel>>(result);
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
