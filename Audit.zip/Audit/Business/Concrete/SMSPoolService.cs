﻿using Business.Abstract;
using Business.Constants;
using Core.Utilities.Results;
using DataAccess.Abstract.UnitOfWork;
using Entities.Dtos;
using Entities.Models;
using System;
using Mapster;
using System.Threading.Tasks;

namespace Business.Concrete
{
    public class SMSPoolService : ISMSPoolService
    {
        private readonly IUnitOfWork _unitOfWork;

        public SMSPoolService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public async Task<IDataResult<SMSDto>> CreateSmsAsync(SMSPool smsPool)
        {
            try
            {
                var data =  await _unitOfWork.SMSPoolDal.AddReturnEntityAsync(smsPool);

                SMSDto smsDto = data.Adapt<SMSDto>();
                return new SuccessDataResult<SMSDto>(smsDto,Messages.SmsSuccess);
            }
            catch (Exception)
            {
                await _unitOfWork.DisposeAsync();
                return new SuccessDataResult<SMSDto>(Messages.SmsError);
            }
        }
    }
}
