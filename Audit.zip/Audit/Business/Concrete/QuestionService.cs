﻿using Business.Abstract;
using DataAccess.Abstract.UnitOfWork;
using Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.Concrete
{
    public class QuestionService : IQuestionService
    {
        private readonly IUnitOfWork _unitOfWork;

        public QuestionService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<IList<Question>> GetQuestionAll()
        {
            try
            {
                var result = await _unitOfWork.QuestionDal.GetAllAsync();

                return result.ToList();
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                return new List<Question>();
            }
           
        }

        public async Task<IList<AssignedQuestions>> GetQuestionsAsync(int questionGroupId)
        {
            return await _unitOfWork.QuestionDal.GetQuestionsAsync(questionGroupId);
        }
    }
}
