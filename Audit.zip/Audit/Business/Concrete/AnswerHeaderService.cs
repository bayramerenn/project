﻿using Business.Abstract;
using Business.Constants;
using Core.Utilities.Results;
using DataAccess.Abstract.UnitOfWork;
using Entities.Dtos;
using Entities.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Business.Concrete
{
    public class AnswerHeaderService : IAnswerHeaderService
    {
        private readonly IUnitOfWork _unitOfWork;

        public AnswerHeaderService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<IDataResult<AnswerHeader>> CreateAnswerHeaderAsync(AnswerHeader answerHeader)
        {
            try
            {
                await _unitOfWork.AnswerHeaderDal.AddAsync(answerHeader);
                await _unitOfWork.CommitAsync();
                return new SuccessDataResult<AnswerHeader>(answerHeader);
            }
            catch (Exception ex)
            {
                await _unitOfWork.DisposeAsync();
                return new ErrorDataResult<AnswerHeader>(Messages.AnswerHeaderError);
            }
        }

        public async Task<IResult> DeleteAnswerHeaderAsync(int answerHeaderId)
        {
            try
            {
                var result = await _unitOfWork.AnswerHeaderDal.DeleteAnswer(answerHeaderId);
                await _unitOfWork.CommitAsync();

                return new SuccessResult(Messages.AnswerHeaderSuccessDeleted);
            }
            catch (Exception ex)
            {
                await _unitOfWork.DisposeAsync();
                return new ErrorResult(Messages.AnswerHeaderErrorDeleted + "" + ex.Message);
            }
        }

        public async Task<AnswerHeader> GetAnswerHeaderAsync(int answerHeaderId)
        {
            return await _unitOfWork.AnswerHeaderDal.GetByIdAsync(answerHeaderId);
        }

        

        public async Task<IList<PendingSurvey>> GetPendingSurveysAsync(int[] headerIds)
        {
            var result =await _unitOfWork.AnswerHeaderDal.GetPendingSurveysAsync(headerIds);
            return result;
        }

        public async Task UpdateAnswerHeaderAsync(AnswerHeader answerHeader)
        {
            try
            {
                _unitOfWork.AnswerHeaderDal.Update(answerHeader);
                await _unitOfWork.CommitAsync();
            }
            catch (Exception)
            {
                await _unitOfWork.DisposeAsync();
            }
        }

        public async Task<Result> UpdateAnswerHeaderPhotoAsync(int answerHeaderId, string imagePath)
        {

            try
            {
                var image = await GetAnswerHeaderImagePathAsync(answerHeaderId);
                int result;
                if (image != null && image != "")
                {

                    image += "&" + imagePath;
                    result = await _unitOfWork.AnswerHeaderDal.UpdateAnswerHeaderPhotoAsync(answerHeaderId, image);
                }
                else
                {
                    result = await _unitOfWork.AnswerHeaderDal.UpdateAnswerHeaderPhotoAsync(answerHeaderId, imagePath);
                }
               

                return new SuccessResult(Messages.AnswerHeaderPhotoUpdatedSuccess);
            }
            catch (Exception)
            {
                return new ErrorResult(Messages.AnswerHeaderPhotoUpdatedError);

            }
           

            
        }
        public async Task<string> GetAnswerHeaderImagePathAsync(int answerHeaderId)
        {
            var result = await _unitOfWork.AnswerHeaderDal.GetByIdAsync(answerHeaderId);
            return result.ImagePath;
        }

        public async Task<Result> DeleteAnswerHeaderPhotoAsync(int answerHeaderId, string imageName)
        {
            try
            {
                string imagePath = string.Empty;

                var image = await GetAnswerHeaderImagePathAsync(answerHeaderId);

                var imageSplit = image.Split("&");

                

                for (int i = 0; i < imageSplit.Length; i++)
                {
                    if (!imageSplit[i].Contains(imageName))
                    {
                        imagePath += imageSplit[i];

                        if (i == imageSplit.Length-1 || i == imageSplit.Length - 2)
                        {
                            imagePath += "";
                        }
                        else
                        {
                            imagePath += "&";
                        }
                       
                    }
                }


                var result = await _unitOfWork.AnswerHeaderDal.UpdateAnswerHeaderPhotoAsync(answerHeaderId, imagePath);

                return new SuccessResult(Messages.AnswerHeaderPhotoDeletedSuccess);
            }
            catch (Exception)
            {
                return new ErrorResult(Messages.AnswerHeaderPhotoUpdatedError);

            }
        }

        public async Task<IResult> UpdateHeaderWizardDtoAsync(HeaderWizardDto headerWizardDto)
        {
            try
            {
                var data = await _unitOfWork.AnswerHeaderDal.UpdateHeaderWizardDtoAsync(headerWizardDto);
                if (data > 0)
                {
                  return  new SuccessResult(Messages.HeaderWizardUpdate);
                }
                return new ErrorResult(Messages.HeaderWizardError);
            }
            catch (Exception ex)
            {
                return new ErrorResult(Messages.HeaderWizardError +" "+ex.Message);
               
            }
        }

        public async Task<IResult> RemoveImagePathReset(int answerHeaderId)
        {
            await _unitOfWork.AnswerHeaderDal.RemoveImagePathReset(answerHeaderId);
            return new SuccessResult();
        }
    }
}