﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Business.Constants
{
    public static class Messages
    {
        public static string AnswerHeaderCreated = "Anket başlatıldı";
        public static string AnswerHeaderError = "Anket oluşturuluken bir hata meydana geldi";
        public static string AnswerHeaderSuccessDeleted = "Anket silinmistir";
        public static string AnswerHeaderErrorDeleted = "Anket silinirken bir hata meydana geldi.";
        internal static string AnswerLineSuccessCreated = "Anket oluşturuldu.";
        public static string AnswerLineErrorDeleted = "Anket oluşturulurken bir hata meydana geldi.";
        public static string UsingMailAdress = "Mail adresi kullaniyor";
        public static string CreatedUser= "Kullanıcı başarıyla oluşturuldu";
        public static string RoleExisting = "Role daha önce açıldı";
        public static string RoleError = "Role oluşturulurken bir hata meydana geldi";
        public static string RoleCreated = " isimli role oluşturuldu";
        public static string SmsSuccess = "Sms Gönderildi";
        public static string SmsError = "Sms gönderimi sırasında bir hata oluştu";

        public static string AnswerHeaderPhotoUpdatedSuccess = "Resim eklendi";
        public static string AnswerHeaderPhotoUpdatedError = "Resim eklenirken bir hata meydana geldi";
        public static string AnswerHeaderAzuraPhotoError = "Resim eklenemedi lütfen IT ekibinden destek alınız";
        public static string AnswerHeaderAzuraPhotoDeleteError = "Resim silinemedi lütfen IT ekibinden destek alınız";

        public static string AnswerHeaderPhotoDeletedSuccess = "Resim silindi";
        public static string AnswerHeaderPhotoDeletedError = "Resim silinirken bir hata meydana geldi";

        public static string HeaderWizardUpdate = "Anket başlığı güncellenmiştir";
        public static string HeaderWizardError = "Anket başlığı güncellenirken bir hata meydana geldi";
    }
}
