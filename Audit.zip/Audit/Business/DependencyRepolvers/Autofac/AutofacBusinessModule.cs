﻿using Autofac;
using Business.Abstract;
using Business.Concrete;
using Core.Utilities.AzureStorage;
using DataAccess.Abstract.UnitOfWork;
using DataAccess.Concrete;
using DataAccess.Concrete.EntityFramework.Context;
using Microsoft.EntityFrameworkCore;

namespace Business.DependencyRepolvers.Autofac
{
    public class AutofacBusinessModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<StoreService>().As<IStoreService>();
            builder.RegisterType<QuestionGroupService>().As<IQuestionGroupService>();
            builder.RegisterType<QuestionService>().As<IQuestionService>();
            builder.RegisterType<AnswerHeaderService>().As<IAnswerHeaderService>();
            builder.RegisterType<BlobStorage>().As<IBlobStorage>();
            builder.RegisterType<AnswerLineService>().As<IAnswerLineService>();
            builder.RegisterType<SMSPoolService>().As<ISMSPoolService>();
            builder.RegisterType<PersonelService>().As<IPersonelService>();


            builder.RegisterType<UnitOfWork>().As<IUnitOfWork>();
            

            builder.Register(x =>
            {
                var optionsBuilder = new DbContextOptionsBuilder<DenetimDbContext>();
                optionsBuilder.UseSqlServer(@"Server=localhost,1433\\Catalog=myDatabase;Database=DenetimDb;User=sa;Password=MyPass@word;");
                return new DenetimDbContext(optionsBuilder.Options);
            }).InstancePerLifetimeScope();

            builder.Register(x =>
            {
                var optionsBuilder = new DbContextOptionsBuilder<CivilDbContext>();
                optionsBuilder.UseSqlServer(@"Enteg datası oldugu ıcın paylasamıyorum");
                return new CivilDbContext(optionsBuilder.Options);
            }).InstancePerLifetimeScope();
        }

        //configuration.GetConnectionString("YOURCONNECTIONSTRING")
    }
}