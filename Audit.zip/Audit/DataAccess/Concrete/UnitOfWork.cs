﻿using DataAccess.Abstract;
using DataAccess.Abstract.UnitOfWork;
using DataAccess.Concrete.EntityFramework;
using DataAccess.Concrete.EntityFramework.Context;
using System.Threading.Tasks;

namespace DataAccess.Concrete
{
    public class UnitOfWork : IUnitOfWork
    {
        private DenetimDbContext _denetimDbContext;

        public UnitOfWork(DenetimDbContext denetimDbContext)
        {
            _denetimDbContext = denetimDbContext;
        }

        private EfStoreDal _efStoreDal;
        private EfQuestionGroupDal _efQuestionGroupDal;
        private EfQuestionDal _efQuestionDal;
        private EfAnswerHeaderDal _efAnswerHeaderDal;
        private EfAnswerLineDal _efAnswerLineDal;
        private EfSMSPoolDal _efSMSPoolDal;

        public IStoreDal StoreDal => _efStoreDal = _efStoreDal ?? new EfStoreDal(_denetimDbContext);

        public IQuestionGroupDal QuestionGroupDal => _efQuestionGroupDal = _efQuestionGroupDal ?? new EfQuestionGroupDal(_denetimDbContext);

        public IQuestionDal QuestionDal => _efQuestionDal = _efQuestionDal ?? new EfQuestionDal(_denetimDbContext);

        public IAnswerHeaderDal AnswerHeaderDal => _efAnswerHeaderDal = _efAnswerHeaderDal ?? new EfAnswerHeaderDal(_denetimDbContext);

        public IAnswerLineDal AnswerLineDal => _efAnswerLineDal = _efAnswerLineDal ?? new EfAnswerLineDal(_denetimDbContext);

        public ISMSPoolDal SMSPoolDal => _efSMSPoolDal = _efSMSPoolDal ?? new EfSMSPoolDal(_denetimDbContext);

        public async Task CommitAsync()
        {
            await _denetimDbContext.SaveChangesAsync();
        }

        public void Commit()
        {
            _denetimDbContext.SaveChangesAsync();
        }

        public void Dispose()
        {
            _denetimDbContext.Dispose();
        }

        public async Task DisposeAsync()
        {
            await _denetimDbContext.DisposeAsync();
        }
    }
}