﻿using DataAccess.Abstract;
using DataAccess.Concrete.EntityFramework.Context;
using DataAccess.Repository;
using Entities.Dtos;
using Entities.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Concrete.EntityFramework
{
    public class EfAnswerHeaderDal :EfEntityRepository<AnswerHeader>, IAnswerHeaderDal
    {
        private DenetimDbContext denetimDb { get => _context as DenetimDbContext; }

        public EfAnswerHeaderDal(DenetimDbContext context) : base(context)
        {
        }

        public async Task<int> DeleteAnswer(int answerHeaderId)
        {
            var data = await denetimDb.Database.ExecuteSqlRawAsync($"EXEC dbo.sp_DeleteAnswer @AnswerHeaderId = {answerHeaderId}");

            return data;
        }

        public async Task<IList<PendingSurvey>> GetPendingSurveysAsync(int[] headerIds)
        {
            string str = string.Join(",",headerIds);

            string query = @$"SELECT AnswerHeaderId,StartTime,StoreDescription,QuestionGroupName FROM dbo.AnswerHeaders WITH(NOLOCK) 
                                    JOIN dbo.Stores WITH(NOLOCK) ON Stores.StoreId = AnswerHeaders.StoreId
                                    JOIN dbo.QuestionGroups WITH(NOLOCK) ON QuestionGroups.QuestionGroupId = AnswerHeaders.QuestionGroupId
                                    WHERE AnswerHeaderId IN({str})";
            var result = await denetimDb.PendingSurveys.FromSqlRaw(query).AsNoTracking().ToListAsync();
            return result;
        }

      

        public async Task<int> UpdateAnswerHeaderPhotoAsync(int answerHeaderId, string imagePath)
        {
            var data = await denetimDb.Database.ExecuteSqlRawAsync($"EXEC sp_UpdateAnswerHeaderPhoto @AnswerHeaderId={answerHeaderId},@ImagePath='{imagePath}'");
            return data;
        }

        public async Task<int> UpdateHeaderWizardDtoAsync(HeaderWizardDto headerWizardDto)
        {
            var data = await denetimDb.Database.ExecuteSqlRawAsync($@"
                    EXEC sp_UpdateHeaderWizardDto 
                        @AnswerHeaderId={headerWizardDto.AnswerHeaderId},
                        @Latitude={headerWizardDto.Latitude},
                        @Longitude={headerWizardDto.Longitude},
                        @SmsId={headerWizardDto.SmsId},
                        @Comment='{headerWizardDto.Comment}'");
            return data;
        }

        public async Task<int> RemoveImagePathReset(int answerHeaderId)
        {
            var data = await denetimDb.Database.ExecuteSqlRawAsync($"EXEC sp_RemoveImagePathReset @AnswerHeaderId={answerHeaderId}");
            return data;
        }
    }
}
