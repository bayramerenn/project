﻿using DataAccess.Abstract;
using DataAccess.Concrete.EntityFramework.Context;
using DataAccess.Repository;
using Entities.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccess.Concrete.EntityFramework
{
    public class EfAnswerLineDal : EfEntityRepository<AnswerLine>, IAnswerLineDal
    {
        private DenetimDbContext denetimDb { get => _context as DenetimDbContext; }

        public EfAnswerLineDal(DenetimDbContext context) : base(context)
        {
        }
    }
}
