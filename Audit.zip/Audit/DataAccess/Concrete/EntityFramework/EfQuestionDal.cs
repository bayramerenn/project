﻿using DataAccess.Abstract;
using DataAccess.Concrete.EntityFramework.Context;
using DataAccess.Repository;
using Entities.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Concrete.EntityFramework
{
    public class EfQuestionDal : EfEntityRepository<Question>, IQuestionDal
    {
        private DenetimDbContext denetimDb { get => _context as DenetimDbContext; }

        public EfQuestionDal(DenetimDbContext context) : base(context)
        {
        }
        public async Task<IList<AssignedQuestions>> GetQuestionsAsync(int questionGroupId)
        {
            return await denetimDb.AssignedQuestions.FromSqlRaw($"EXEC sp_GetQuestionsByGroupId @QuestionGroupId= {questionGroupId}").AsNoTracking().ToListAsync();
        }
    }
}
