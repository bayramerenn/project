﻿using DataAccess.Abstract;
using DataAccess.Concrete.EntityFramework.Context;
using DataAccess.Repository;
using Entities.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DataAccess.Concrete.EntityFramework
{
    public class EfStoreDal : EfEntityRepository<Store>, IStoreDal
    {
        private DenetimDbContext denetimDb { get => _context as DenetimDbContext; }

        public EfStoreDal(DenetimDbContext context) : base(context)
        {
        }

        public async Task<List<Store>> GetStoresAsync()
        {
            return await denetimDb.Store.FromSqlRaw("EXEC sp_GetStores").AsNoTracking().ToListAsync();
        }
    }
}