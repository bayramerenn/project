﻿using DataAccess.Abstract;
using DataAccess.Concrete.EntityFramework.Context;
using DataAccess.Repository;
using Entities.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DataAccess.Concrete.EntityFramework
{
    public class EfQuestionGroupDal : EfEntityRepository<QuestionGroup>, IQuestionGroupDal
    {
        private DenetimDbContext denetimDb { get => _context as DenetimDbContext; }

        public EfQuestionGroupDal(DenetimDbContext context) : base(context)
        {
        }

        public async Task<IList<QuestionGroup>> GetQuestionGroupsAsync(int storeId)
        {
            return await denetimDb.QuestionGroup.FromSqlRaw($"EXEC sp_GetStoreQuestionGroups @StoreId = {storeId}").AsNoTracking().ToListAsync();
        }
    }
}