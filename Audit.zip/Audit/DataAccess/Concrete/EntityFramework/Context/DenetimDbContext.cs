﻿using Entities.Models;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Concrete.EntityFramework.Context
{
    public class DenetimDbContext : DbContext
    {
        public DenetimDbContext(DbContextOptions<DenetimDbContext> options) : base(options)
        {
        }

        public DbSet<Store> Store { get; set; }
        public DbSet<QuestionGroup> QuestionGroup { get; set; }
        public DbSet<AssignedQuestions> AssignedQuestions { get; set; }
        public DbSet<AnswerHeader> AnswerHeaders { get; set; }
        public DbSet<AnswerLine> AnswerLines { get; set; }
        public DbSet<PendingSurvey> PendingSurveys{ get; set; }
        public DbSet<SMSPool> SMSPools{ get; set; }
        public DbSet<Question> Questions{ get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<PendingSurvey>(eb => eb.HasNoKey());
        }
    }
}