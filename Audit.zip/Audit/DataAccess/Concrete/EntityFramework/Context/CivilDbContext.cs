﻿using Entities.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccess.Concrete.EntityFramework.Context
{
    public class CivilDbContext : DbContext
    {
        public CivilDbContext(DbContextOptions<CivilDbContext> options) : base(options)
        { }
         public DbSet<NebimPersonel> NebimPersonel { get; set; }
  
    

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<NebimPersonel>(eb => eb.HasNoKey());
        }
    }
}
