﻿using Core.DataAccess;
using Entities.Dtos;
using Entities.Models;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DataAccess.Abstract
{
    public interface IAnswerHeaderDal : IEntityRepository<AnswerHeader>
    {
        public Task<int> DeleteAnswer(int answerHeaderId);
        public Task<IList<PendingSurvey>> GetPendingSurveysAsync(int[] headerIds);
   
        public Task<int> UpdateAnswerHeaderPhotoAsync(int answerHeaderId,string imagePath);
        public Task<int> UpdateHeaderWizardDtoAsync(HeaderWizardDto headerWizardDto);
        public Task<int> RemoveImagePathReset(int answerHeaderId);

    }
}