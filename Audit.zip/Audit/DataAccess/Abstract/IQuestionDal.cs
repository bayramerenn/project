﻿using Core.DataAccess;
using Entities.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Abstract
{
    public interface IQuestionDal : IEntityRepository<Question>
    {
        Task<IList<AssignedQuestions>> GetQuestionsAsync(int questionGroupId);
       
    }
}
