﻿using System;
using System.Threading.Tasks;

namespace DataAccess.Abstract.UnitOfWork
{
    public interface IUnitOfWork : IDisposable
    {
        IStoreDal StoreDal { get; }
        IQuestionGroupDal QuestionGroupDal { get; }
        IQuestionDal QuestionDal { get; }
        IAnswerHeaderDal AnswerHeaderDal { get; }
        IAnswerLineDal AnswerLineDal { get; }
        ISMSPoolDal SMSPoolDal { get; }

        Task CommitAsync();

        void Commit();

        Task DisposeAsync();
    }
}