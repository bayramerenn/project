﻿using Core.DataAccess;
using Entities.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DataAccess.Abstract
{
    public interface IStoreDal : IEntityRepository<Store>
    {
        Task<List<Store>> GetStoresAsync();
    }
}