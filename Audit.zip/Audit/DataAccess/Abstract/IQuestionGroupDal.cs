﻿using Core.DataAccess;
using Entities.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DataAccess.Abstract
{
    public interface IQuestionGroupDal : IEntityRepository<QuestionGroup>
    {
        Task<IList<QuestionGroup>> GetQuestionGroupsAsync(int storeId);
    }
}